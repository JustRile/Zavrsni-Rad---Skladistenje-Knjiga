﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmObjekti
	{
		public frmObjekti()
		{
			InitializeComponent();
		}

		private int m_VrstaObjekta;
		private DataTable m_Magacini;
		private DataTable m_Data;

		public void Init(int _Vrsta)
		{
			m_VrstaObjekta = _Vrsta;
		}

		private void frmObjekti_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			string gr = null;
			if (m_VrstaObjekta == 1)
			{
				m_Data = SrednjiSloj.Pravila.VratiKnjizareZaMagacin(0, ref gr);
				m_Magacini = SrednjiSloj.Pravila.VratiSpisakMagacina(ref gr);
				cboPripada.DisplayMember = "naziv";
				cboPripada.ValueMember = "objid";
				cboPripada.DataSource = m_Magacini;
				cboPripada.Visible = true;
				this.Text = "Spisak knjižara";
			}
			else
			{
				m_Data = SrednjiSloj.Pravila.VratiSpisakMagacina(ref gr);
				this.Text = "Spisak magacina";
			}
			m_Data.Columns.Add("aktivno", typeof(bool));
			foreach (DataRow r in m_Data.Rows)
			{
				r["aktivno"] = Convert.ToBoolean(true);
			}
			m_Data.AcceptChanges();
			dgData.AutoGenerateColumns = false;
			dgData.Columns[0].DataPropertyName = "objid";
			dgData.Columns[1].DataPropertyName = "objvrsta";
			dgData.Columns[2].DataPropertyName = "naziv";
			dgData.Columns[3].DataPropertyName = "adresa";
			dgData.Columns[4].DataPropertyName = "mesto";
			dgData.Columns[5].DataPropertyName = "pripada";
			dgData.Columns[6].DataPropertyName = "vazi";
			dgData.Columns[7].DataPropertyName = "aktivno";
			dgData.DataSource = m_Data;
		}

		private void dgData_CellContentClick(System.Object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
		{

		}

		private void dgData_UserAddedRow(object sender, System.Windows.Forms.DataGridViewRowEventArgs e)
		{
			if (dgData.CurrentRow != null)
			{
				dgData.CurrentRow.Cells[0].Value = 0;
				dgData.CurrentRow.Cells[1].Value = m_VrstaObjekta;
				if (m_VrstaObjekta == 2)
				{
					dgData.CurrentRow.Cells[5].Value = 0;
				}
				else
				{
					dgData.CurrentRow.Cells[5].Value = 1;
				}
				dgData.CurrentRow.Cells[3].Value = "";
				dgData.CurrentRow.Cells[4].Value = "";
				dgData.CurrentRow.Cells[6].Value = "1";
				dgData.CurrentRow.Cells[7].Value = Convert.ToBoolean(true);
			}
		}

		private void cmdOK_Click(System.Object sender, System.EventArgs e)
		{
			string gr = null;
			if (m_VrstaObjekta == 2)
			{
				foreach (DataRow r in m_Data.Rows)
				{
					if (r.RowState != DataRowState.Unchanged)
					{
						if (Convert.ToBoolean(r["aktivno"]))
						{
							DataTable t = SrednjiSloj.Pravila.EvidentirajMagacin(Convert.ToInt32(r[0]), "", r[4].ToString(), r[5].ToString(), r[6].ToString(), "1", ref gr);
							if (t != null)
							{
								if (Convert.ToInt32(r[0]) == 0)
								{
									r[0] = t.Rows[0][0];
								}
							}
						}
						else
						{
							r[6] = "0";
							DataTable t = SrednjiSloj.Pravila.EvidentirajMagacin(Convert.ToInt32(r[0]), "", r[4].ToString(), r[5].ToString(), r[6].ToString(), "0", ref gr);
							if (t != null)
							{
								if (Convert.ToInt32(r[0]) == 0)
								{
									r[0] = t.Rows[0][0];
								}
							}
						}
					}
				}
			}
			else
			{
				foreach (DataRow r in m_Data.Rows)
				{
					if (r.RowState != DataRowState.Unchanged)
					{
						if (Convert.ToBoolean(r["aktivno"]))
						{
							DataTable t = SrednjiSloj.Pravila.EvidentirajKnjizaru(Convert.ToInt32(r[0]), Convert.ToInt32(r[2]), "", r[4].ToString(), r[5].ToString(), r[6].ToString(), "1", ref gr);
							if (t != null)
							{
								if (Convert.ToInt32(r[0]) == 0)
								{
									r[0] = t.Rows[0][0];
								}
							}
						}
						else
						{
							r[6] = "0";
							DataTable t = SrednjiSloj.Pravila.EvidentirajKnjizaru(Convert.ToInt32(r[0]), Convert.ToInt32(r[2]), "", r[4].ToString(), r[5].ToString(), r[6].ToString(), "0", ref gr);
							if (t != null)
							{
								if (Convert.ToInt32(r[0]) == 0)
								{
									r[0] = t.Rows[0][0];
								}
							}
						}
					}
				}
			}
		}
	}
}