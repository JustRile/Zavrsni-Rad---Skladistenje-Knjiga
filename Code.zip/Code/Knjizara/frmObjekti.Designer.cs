﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmObjekti : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmObjekti));
			this.dgData = new System.Windows.Forms.DataGridView();
			this.obkid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.objvrsta = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.naziv = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.adresa = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.mesto = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.cboPripada = new System.Windows.Forms.DataGridViewComboBoxColumn();
			this.vazi = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.aktivno = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.cmdOK = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)this.dgData).BeginInit();
			this.SuspendLayout();
			//
			//dgData
			//
			this.dgData.Anchor = (System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right);
			this.dgData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {this.obkid, this.objvrsta, this.naziv, this.adresa, this.mesto, this.cboPripada, this.vazi, this.aktivno});
			this.dgData.Location = new System.Drawing.Point(10, 12);
			this.dgData.Name = "dgData";
			this.dgData.Size = new System.Drawing.Size(574, 222);
			this.dgData.TabIndex = 6;
			//
			//obkid
			//
			this.obkid.HeaderText = "ID";
			this.obkid.Name = "obkid";
			this.obkid.Visible = false;
			//
			//objvrsta
			//
			this.objvrsta.HeaderText = "vrsta";
			this.objvrsta.Name = "objvrsta";
			this.objvrsta.Visible = false;
			//
			//naziv
			//
			this.naziv.HeaderText = "Naziv";
			this.naziv.Name = "naziv";
			this.naziv.Width = 200;
			//
			//adresa
			//
			this.adresa.HeaderText = "Adresa";
			this.adresa.Name = "adresa";
			//
			//mesto
			//
			this.mesto.HeaderText = "Mesto";
			this.mesto.Name = "mesto";
			//
			//cboPripada
			//
			this.cboPripada.HeaderText = "Magacin";
			this.cboPripada.Name = "cboPripada";
			this.cboPripada.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.cboPripada.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			this.cboPripada.Visible = false;
			//
			//vazi
			//
			this.vazi.HeaderText = "vazi";
			this.vazi.Name = "vazi";
			this.vazi.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.vazi.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.vazi.Visible = false;
			//
			//aktivno
			//
			this.aktivno.HeaderText = "Važi";
			this.aktivno.Name = "aktivno";
			this.aktivno.Width = 60;
			//
			//cmdOK
			//
			this.cmdOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.cmdOK.Image = (System.Drawing.Image)resources.GetObject("cmdOK.Image");
			this.cmdOK.Location = new System.Drawing.Point(254, 240);
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.Size = new System.Drawing.Size(75, 23);
			this.cmdOK.TabIndex = 7;
			this.cmdOK.UseVisualStyleBackColor = true;
			//
			//frmObjekti
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(587, 264);
			this.Controls.Add(this.cmdOK);
			this.Controls.Add(this.dgData);
			this.Name = "frmObjekti";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmMagacin";
			((System.ComponentModel.ISupportInitialize)this.dgData).EndInit();
			this.ResumeLayout(false);

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmObjekti_Load);
			dgData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgData_CellContentClick);
			dgData.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(dgData_UserAddedRow);
			cmdOK.Click += new System.EventHandler(cmdOK_Click);
		}
		internal System.Windows.Forms.DataGridView dgData;
		internal System.Windows.Forms.Button cmdOK;
		internal System.Windows.Forms.DataGridViewTextBoxColumn obkid;
		internal System.Windows.Forms.DataGridViewTextBoxColumn objvrsta;
		internal System.Windows.Forms.DataGridViewTextBoxColumn naziv;
		internal System.Windows.Forms.DataGridViewTextBoxColumn adresa;
		internal System.Windows.Forms.DataGridViewTextBoxColumn mesto;
		internal System.Windows.Forms.DataGridViewComboBoxColumn cboPripada;
		internal System.Windows.Forms.DataGridViewTextBoxColumn vazi;
		internal System.Windows.Forms.DataGridViewCheckBoxColumn aktivno;
	}

}