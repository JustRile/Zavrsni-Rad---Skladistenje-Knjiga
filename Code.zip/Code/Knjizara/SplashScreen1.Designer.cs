﻿using System.Xml;

//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class SplashScreen1 : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SplashScreen1));
			this.ApplicationTitle = new System.Windows.Forms.Label();
			this.Version = new System.Windows.Forms.Label();
			this.Copyright = new System.Windows.Forms.Label();
			this.BackgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.SuspendLayout();
			//
			//ApplicationTitle
			//
			this.ApplicationTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.ApplicationTitle.BackColor = System.Drawing.Color.Transparent;
			this.ApplicationTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.0F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (byte)0);
			this.ApplicationTitle.ForeColor = System.Drawing.Color.White;
			this.ApplicationTitle.Location = new System.Drawing.Point(167, 9);
			this.ApplicationTitle.Name = "ApplicationTitle";
			this.ApplicationTitle.Size = new System.Drawing.Size(328, 32);
			this.ApplicationTitle.TabIndex = 3;
			this.ApplicationTitle.Text = "Application Title";
			this.ApplicationTitle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			//
			//Version
			//
			this.Version.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.Version.BackColor = System.Drawing.Color.Transparent;
			this.Version.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.0F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (byte)0);
			this.Version.ForeColor = System.Drawing.Color.White;
			this.Version.Location = new System.Drawing.Point(254, 85);
			this.Version.Name = "Version";
			this.Version.Size = new System.Drawing.Size(241, 17);
			this.Version.TabIndex = 4;
			this.Version.Text = "Version {0}.{1:00}";
			this.Version.TextAlign = System.Drawing.ContentAlignment.TopRight;
			//
			//Copyright
			//
			this.Copyright.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.Copyright.BackColor = System.Drawing.Color.Transparent;
			this.Copyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.0F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (byte)0);
			this.Copyright.ForeColor = System.Drawing.Color.White;
			this.Copyright.Location = new System.Drawing.Point(254, 124);
			this.Copyright.Name = "Copyright";
			this.Copyright.Size = new System.Drawing.Size(241, 32);
			this.Copyright.TabIndex = 5;
			this.Copyright.Text = "Copyright";
			this.Copyright.TextAlign = System.Drawing.ContentAlignment.TopRight;
			//
			//BackgroundWorker1
			//
			//
			//SplashScreen1
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (System.Drawing.Image)resources.GetObject("$this.BackgroundImage");
			this.ClientSize = new System.Drawing.Size(496, 303);
			this.ControlBox = false;
			this.Controls.Add(this.ApplicationTitle);
			this.Controls.Add(this.Version);
			this.Controls.Add(this.Copyright);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SplashScreen1";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.ResumeLayout(false);

//INSTANT C# NOTE: Converted design-time event handler wireups:
			this.Load += new System.EventHandler(SplashScreen1_Load);
		}
		internal System.Windows.Forms.Label ApplicationTitle;
		internal System.Windows.Forms.Label Version;
		internal System.Windows.Forms.Label Copyright;
		internal System.ComponentModel.BackgroundWorker BackgroundWorker1;

	}

}