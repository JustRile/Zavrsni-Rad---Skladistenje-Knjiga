﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public class DB
	{
		private static System.Data.SqlClient.SqlConnection m_DB;

		public static bool Connect(ref string _Error)
		{
			bool fja = false;
			if (m_DB == null)
			{
				if (Properties.Settings.Default.Trusted)
				{
					try
					{
						m_DB = new System.Data.SqlClient.SqlConnection("Server=" + Properties.Settings.Default.DBServer + ";Database=" + Properties.Settings.Default.DBName + ";Trusted_Connection=True;");
						m_DB.Open();
						m_DB.Close();
						fja = true;
					}
					catch (Exception ex)
					{
						_Error = ex.Message;
					}
				}
				else
				{
					if (Properties.Settings.Default.DBPWD.Trim().Length > 0)
					{
						try
						{
							m_DB = new System.Data.SqlClient.SqlConnection("Server=" + Properties.Settings.Default.DBServer + ";Database=" + Properties.Settings.Default.DBName + ";User Id=Knjige;Password=" + Properties.Settings.Default.DBPWD + ";");
							m_DB.Open();
							m_DB.Close();
							fja = true;
						}
						catch (Exception ex1)
						{
							_Error = ex1.Message;
						}
					}
					else
					{
						_Error = "Mora se definisati lozinka za prijavu na bazu.";
					}
				}
			}
			else
			{
				fja = true;
			}
			return fja;
		}

		public static bool Disconnect(ref string _Error)
		{
			bool fja = false;
			if (m_DB == null)
			{
				fja = true;
			}
			else
			{
				try
				{
					m_DB.Close();
					m_DB.Dispose();
					m_DB = null;
					fja = true;
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
			}
			return fja;
		}

		public static DataTable GetData(string _SQL, ref string _Error)
		{
			DataTable fja = null;
			if (DB.Connect(ref _Error))
			{
				System.Data.SqlClient.SqlDataAdapter ada = null;
				try
				{
					ada = new System.Data.SqlClient.SqlDataAdapter(_SQL, m_DB);
					m_DB.Open();
					fja = new DataTable();
					ada.Fill(fja);
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					ada.Dispose();
					ada = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static DataTable GetData(System.Data.SqlClient.SqlCommand _SQL, ref string _Error)
		{
			DataTable fja = null;
			if (DB.Connect(ref _Error))
			{
				System.Data.SqlClient.SqlDataAdapter ada = null;
				try
				{
					_SQL.CommandType = CommandType.StoredProcedure;
					_SQL.Connection = m_DB;
					ada = new System.Data.SqlClient.SqlDataAdapter(_SQL);
					m_DB.Open();
					fja = new DataTable();
					ada.Fill(fja);
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					ada.Dispose();
					ada = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static DataSet GetDS(string _SQL, ref string _Error)
		{
			DataSet fja = null;
			if (DB.Connect(ref _Error))
			{
				System.Data.SqlClient.SqlDataAdapter ada = null;
				try
				{
					ada = new System.Data.SqlClient.SqlDataAdapter(_SQL, m_DB);
					m_DB.Open();
					fja = new DataSet();
					ada.Fill(fja);
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					ada.Dispose();
					ada = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static DataSet GetDS(System.Data.SqlClient.SqlCommand _SQL, ref string _Error)
		{
			DataSet fja = null;
			if (DB.Connect(ref _Error))
			{
				System.Data.SqlClient.SqlDataAdapter ada = null;
				try
				{
					_SQL.CommandType = CommandType.StoredProcedure;
					_SQL.Connection = m_DB;
					ada = new System.Data.SqlClient.SqlDataAdapter(_SQL);
					m_DB.Open();
					fja = new DataSet();
					ada.Fill(fja);
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					ada.Dispose();
					ada = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static bool Execute(string _SQL, ref string _Error)
		{
			bool fja = false;
			if (DB.Connect(ref _Error))
			{
				System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand(_SQL);
				comm.CommandType = CommandType.Text;
				try
				{
					m_DB.Open();
					comm.Connection = m_DB;
					comm.ExecuteNonQuery();
					fja = true;
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					comm.Dispose();
					comm = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static bool Execute(System.Data.SqlClient.SqlCommand _SQL, ref string _Error)
		{
			bool fja = false;
			if (DB.Connect(ref _Error))
			{
				_SQL.CommandType = CommandType.StoredProcedure;
				try
				{
					m_DB.Open();
					_SQL.Connection = m_DB;
					_SQL.ExecuteNonQuery();
					fja = true;
				}
				catch (Exception ex)
				{
					_Error = ex.Message;
				}
				finally
				{
					_SQL.Dispose();
					_SQL = null;
					m_DB.Close();
				}
			}
			return fja;
		}

		public static object GetValue(string _SQL, ref string _Error)
		{
			object fja = null;
			DataTable tbl = GetData(_SQL, ref _Error);
			if (_Error == null)
			{
				if (tbl != null)
				{
					if (tbl.Rows.Count > 0)
					{
						fja = tbl.Rows[0][0];
					}
					else
					{
						_Error = "No data.";
					}
				}
				else
				{
					_Error = "Not exist.";
				}
			}


			return fja;
		}
	}

}