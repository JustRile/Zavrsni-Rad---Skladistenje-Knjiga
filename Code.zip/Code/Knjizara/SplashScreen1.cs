﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

using System.Xml;

namespace Knjizara
{
	public sealed partial class SplashScreen1
	{
		//Public Sub MakeConnect()
		//    Dim m_Error As String = Nothing
		//    While Not DB.Connect(m_Error)
		//        Threading.Thread.Sleep(100)
		//    End While
		//    Dim t As DataTable = DB.GetData("SELECT * FROM Objekti", m_Error)
		//    If Not m_Error Is Nothing Then
		//        MessageBox.Show(m_Error)
		//    End If
		//End Sub

		//TODO: This form can easily be set as the splash screen for the application by going to the "Application" tab
		//  of the Project Designer ("Properties" under the "Project" menu).


		public SplashScreen1()
		{
			InitializeComponent();
		}

		private void SplashScreen1_Load(object sender, System.EventArgs e)
		{
			//Set up the dialog text at runtime according to the application's assembly information.  

			//TODO: Customize the application's assembly information in the "Application" pane of the project 
			//  properties dialog (under the "Project" menu).
			bool flag = false;
			try
			{
				XmlDocument doc = new XmlDocument();
				doc.Load("Knjizara.exe.config");
				XmlNode MyRootNode = doc.SelectSingleNode("//configuration//applicationSettings//Knjizara.My.MySettings"); //Here you need to change the YourProjectName
				XmlNodeList keyNodes = MyRootNode.SelectNodes(".//setting");
				foreach (XmlNode keyNode in keyNodes)
				{
					if (keyNode.Attributes["name"].Value == "KoristiPrijavu")
					{
						flag = true;
						break;
					}
					else
					{
					}
				}
				//If (flag) Then
				//    MessageBox.Show("has a setting four " & ctrl.Name)
				//Else
				//    MessageBox.Show("Not a setting - the name is " & ctrl.Name)
				//End If
			}
			catch (Exception ex)
			{
				Debug.Print(ex.Message);
				MessageBox.Show(ex.Message);
			}

			//Application title
			if (!string.IsNullOrEmpty(My.MyApplication.Application.Info.Title))
			{
				ApplicationTitle.Text = My.MyApplication.Application.Info.Title;
			}
			else
			{
				//If the application title is missing, use the application name, without the extension
				ApplicationTitle.Text = System.IO.Path.GetFileNameWithoutExtension(My.MyApplication.Application.Info.AssemblyName);
			}

			//Format the version information using the text set into the Version control at design time as the
			//  formatting string.  This allows for effective localization if desired.
			//  Build and revision information could be included by using the following code and changing the 
			//  Version control's designtime text to "Version {0}.{1:00}.{2}.{3}" or something similar.  See
			//  String.Format() in Help for more information.
			//
			//    Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor, My.Application.Info.Version.Build, My.Application.Info.Version.Revision)

			Version.Text = System.String.Format(Version.Text, My.MyApplication.Application.Info.Version.Major, My.MyApplication.Application.Info.Version.Minor);

			//Copyright info
			if (!flag)
			{
				Copyright.Text = "(Trial Version) " + My.MyApplication.Application.Info.Copyright;
			}
			else
			{
				Copyright.Text = My.MyApplication.Application.Info.Copyright.Replace("Malikoja", "");
			}
		}


		private static SplashScreen1 _DefaultInstance;
		public static SplashScreen1 DefaultInstance
		{
			get
			{
				if (_DefaultInstance == null || _DefaultInstance.IsDisposed)
					_DefaultInstance = new SplashScreen1();

				return _DefaultInstance;
			}
		}
	}

}