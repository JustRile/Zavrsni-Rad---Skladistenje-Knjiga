﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public class Podaci
	{
		//Public Shared Function Magacin(ByVal _ID As Integer, ByVal _Sifra As String, ByVal _Naziv As String, ByVal _Adresa As String, ByVal _Mesto As String, ByVal _Vazi As String, ByRef _Error As String) As DataTable
		//    Dim comm As New SqlClient.SqlCommand("ObjektiWork")
		//    comm.CommandType = CommandType.StoredProcedure
		//    comm.Parameters.AddWithValue("@objid", _ID)
		//    comm.Parameters.AddWithValue("@objvrsta", 2)
		//    comm.Parameters.AddWithValue("@pripada", 0)
		//    comm.Parameters.AddWithValue("@sifra", _Sifra)
		//    comm.Parameters.AddWithValue("@naziv", _Naziv)
		//    comm.Parameters.AddWithValue("@adresa", _Adresa)
		//    comm.Parameters.AddWithValue("@mesto", _Mesto)
		//    comm.Parameters.AddWithValue("@vazi", _Vazi)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Public Shared Function Knjizara(ByVal _ID As Integer, ByVal _Magacin As Integer, ByVal _Sifra As String, ByVal _Naziv As String, ByVal _Adresa As String, ByVal _Mesto As String, ByVal _Vazi As String, ByRef _Error As String) As DataTable
		//    Dim comm As New SqlClient.SqlCommand("ObjektiWork")
		//    comm.CommandType = CommandType.StoredProcedure
		//    comm.Parameters.AddWithValue("@objid", _ID)
		//    comm.Parameters.AddWithValue("@objvrsta", 1)
		//    comm.Parameters.AddWithValue("@pripada", _Magacin)
		//    comm.Parameters.AddWithValue("@sifra", _Sifra)
		//    comm.Parameters.AddWithValue("@naziv", _Naziv)
		//    comm.Parameters.AddWithValue("@adresa", _Adresa)
		//    comm.Parameters.AddWithValue("@mesto", _Mesto)
		//    comm.Parameters.AddWithValue("@vazi", _Vazi)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Public Shared Function Knjige(ByVal _ID As Integer, ByVal _ISBN As String, ByVal _Naslov As String, ByVal _Autor As String, ByVal _Godina As Integer, ByRef _Error As String) As DataTable
		//    Dim comm As New SqlClient.SqlCommand("KnjigeWork")
		//    comm.CommandType = CommandType.StoredProcedure
		//    comm.Parameters.AddWithValue("@bookid", _ID)
		//    comm.Parameters.AddWithValue("@isbn", _ISBN)
		//    comm.Parameters.AddWithValue("@naslov", _Naslov)
		//    comm.Parameters.AddWithValue("@autor", _Autor)
		//    comm.Parameters.AddWithValue("@godina", _Godina)
		//    'comm.Parameters.AddWithValue("@vazi", _Vazi)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Public Shared Function Zaposleni(ByVal _ID As Integer, ByVal _Ime As String, ByVal _Sifra As String, ByVal _Lozinka As String, ByVal _RM As Integer, ByVal _Objekat As Integer, ByVal _Vazi As String, ByRef _Error As String) As DataTable
		//    Dim comm As New SqlClient.SqlCommand("ZaposleniWork")
		//    comm.CommandType = CommandType.StoredProcedure
		//    comm.Parameters.AddWithValue("@empid", _ID)
		//    comm.Parameters.AddWithValue("@ime", _Ime)
		//    comm.Parameters.AddWithValue("@sifra", _Sifra)
		//    comm.Parameters.AddWithValue("@lozinka", _Lozinka)
		//    comm.Parameters.AddWithValue("@vrsta", _RM)
		//    comm.Parameters.AddWithValue("@objid", _Objekat)
		//    comm.Parameters.AddWithValue("@objvrsta", 0)
		//    comm.Parameters.AddWithValue("@vazi", _Vazi)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Public Shared Function Magacini(ByRef _Error As String) As DataTable
		//    Return DB.GetData("SELECT * FROM Magacini()", _Error)
		//End Function

		//Public Shared Function KnjizareZa(ByVal _ID As Integer, ByRef _Error As String) As DataTable
		//    If _ID = 0 Then
		//        Return DB.GetData("SELECT * FROM Knjizare()", _Error)
		//    Else
		//        Return DB.GetData("SELECT * FROM KnjizareZa(" + _ID.ToString + ")", _Error)
		//    End If
		//End Function

		//Public Shared Function SviZaposleni(ByRef _Error As String) As DataTable
		//    Return DB.GetData("SELECT * FROM VZaposleni", _Error)
		//End Function

		//Public Shared Function Trebvanje(ByVal _DocID As Integer, ByVal _ObjID As Integer, ByVal _VrstaDoc As Integer, ByVal _Vrsta As Integer,
		//                                 ByVal _Datum As Date, ByVal _Status As String, ByVal _Broj As Integer, ByRef _Oznaka As String, ByRef _Error As String) As DataTable

		//    Dim comm As New SqlClient.SqlCommand("DokumentaWork")
		//    comm.CommandType = CommandType.StoredProcedure

		//    comm.Parameters.AddWithValue("@objid", _ObjID)
		//    comm.Parameters.AddWithValue("@vrstadoc", _VrstaDoc)
		//    comm.Parameters.AddWithValue("@broj", _Broj)
		//    comm.Parameters.AddWithValue("@vrsta", _Vrsta)
		//    comm.Parameters.AddWithValue("@docid", _DocID)
		//    comm.Parameters.AddWithValue("@oznaka", _Oznaka)
		//    comm.Parameters.AddWithValue("@datum", CDate(_Datum))
		//    comm.Parameters.AddWithValue("@empid", 1)
		//    comm.Parameters.AddWithValue("@status", _Status)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Private Shared Function AppDokument(ByVal _DocID As Integer, ByVal _ObjID As Integer, ByVal _VrstaDoc As Integer, ByVal _Vrsta As Integer,
		//                             ByVal _Datum As Date, ByVal _Status As String, ByVal _Broj As Integer, ByVal _Oznaka As String, ByRef _Error As String) As DataTable

		//    Dim comm As New SqlClient.SqlCommand("DokumentaWork")
		//    comm.CommandType = CommandType.StoredProcedure

		//    comm.Parameters.AddWithValue("@objid", _ObjID)
		//    comm.Parameters.AddWithValue("@vrstadoc", _VrstaDoc)
		//    comm.Parameters.AddWithValue("@broj", _Broj)
		//    comm.Parameters.AddWithValue("@vrsta", _Vrsta)
		//    comm.Parameters.AddWithValue("@docid", _DocID)
		//    comm.Parameters.AddWithValue("@oznaka", _Oznaka)
		//    comm.Parameters.AddWithValue("@datum", CDate(_Datum))
		//    comm.Parameters.AddWithValue("@empid", 1)
		//    comm.Parameters.AddWithValue("@status", _Status)
		//    Return DB.GetData(comm, _Error)
		//End Function

		//Public Shared Function Trebovanje(ByVal _DocID As Integer, ByVal _ObjID As Integer, ByVal _Vrsta As Integer,
		//                             ByVal _Datum As Date, ByVal _Status As String, ByRef _Broj As Integer, ByRef _Onaka As String, ByRef _Error As String) As Boolean
		//    Dim fja As Boolean = False
		//    Dim t As DataTable = AppDokument(_DocID, _ObjID, 1, _Vrsta, _Datum, _Status, 0, 0, _Error)
		//    If _Error Is Nothing Then
		//        If t.Rows.Count > 0 Then
		//            _Broj = t.Rows(0).Item("broj")
		//            _Onaka = t.Rows(0).Item("oznaka").ToString
		//            fja = True
		//        End If
		//    End If
		//    Return fja
		//End Function

		//Public Shared Function Prijemnica(ByVal _DocID As Integer, ByVal _ObjID As Integer, ByVal _Vrsta As Integer,
		//                         ByVal _Datum As Date, ByVal _Status As String, ByRef _Broj As Integer, ByRef _Onaka As String, ByRef _Error As String) As Boolean
		//    Dim fja As Boolean = False
		//    Dim t As DataTable = AppDokument(_DocID, _ObjID, 2, _Vrsta, _Datum, _Status, 0, 0, _Error)
		//    If _Error Is Nothing Then
		//        If t.Rows.Count > 0 Then
		//            _Broj = t.Rows(0).Item("broj")
		//            _Onaka = t.Rows(0).Item("oznaka").ToString
		//            fja = True
		//        End If
		//    End If
		//    Return fja
		//End Function

		//Public Shared Function Hodogram(ByVal _DocIz As Integer, ByVal _DocU As Integer, ByVal _Faza As String, ByRef _Error As String) As Boolean
		//    Dim comm As New SqlClient.SqlCommand("HodogramWork")
		//    comm.CommandType = CommandType.StoredProcedure

		//    comm.Parameters.AddWithValue("@dociz", _DocIz)
		//    comm.Parameters.AddWithValue("@docu", _DocU)
		//    comm.Parameters.AddWithValue("@status", _Faza)
		//    Return DB.Execute(comm, _Error)
		//End Function

		//Public Shared Function TrebovanjaZaPakovanje(ByVal _Vrsta As Integer, ByVal _ID As Integer, ByRef _Error As String) As DataTable
		//    If _Vrsta = 1 Then
		//        Return DB.GetData("SELECT * FROM Dokumemta WHERE vrstadoc = 1 and objid = " + _ID.ToString + " AND Status = '1'", _Error)
		//    Else
		//        Return DB.GetData("SELECT * FROM Dokumemta WHERE vrstadoc = 1 and objid in (select objid from Objekti where pripada =  " + _ID.ToString + ") AND Status = '1'", _Error)
		//    End If
		//End Function

		//Public Shared Function EvidPromet(ByVal _DocID As Integer, ByVal _GookID As Integer, ByVal _Zahtevano As Integer, ByVal _Odobreno As Integer, ByRef _Error As String) As Boolean
		//    Dim comm As New SqlClient.SqlCommand("PrometWork")
		//    comm.CommandType = CommandType.StoredProcedure

		//    comm.Parameters.AddWithValue("@docid", _DocID)
		//    comm.Parameters.AddWithValue("@bookid", _GookID)
		//    comm.Parameters.AddWithValue("@zahtevano", _Zahtevano)
		//    comm.Parameters.AddWithValue("@odobreno", _Odobreno)
		//    Return DB.Execute(comm, _Error)
		//End Function
	}

}