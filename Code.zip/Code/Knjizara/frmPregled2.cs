﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmPregled2
	{
		public frmPregled2()
		{
			InitializeComponent();
		}

		private DataTable m_Vrste;
		private string m_Error;

		private DataTable m_Stanje;
		private bool m_IsLoad = true;

		private int m_ActiveVrsta;
		private int m_ActiveObj;

		public void Init(int _ActiveVrsta, int _ActiveObj)
		{
			m_ActiveVrsta = _ActiveVrsta;
			m_ActiveObj = _ActiveObj;
		}

		private void frmPregled_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			m_IsLoad = true;
			//m_Vrste = DB.GetData("SELECT * FROM VrstaRM where vrsta <> 6", m_Error)
			System.String tempVar = "6";
			m_Vrste = SrednjiSloj.Pravila.VratiViewButtons(Convert.ToInt32(m_Error), ref tempVar);
			cboRM.DisplayMember = "naziv";
			cboRM.ValueMember = "vrsta";
			cboRM.DataSource = m_Vrste;

			cboRM.SelectedValue = m_ActiveVrsta;
			cboRM_SelectedIndexChanged(cboRM, new EventArgs());
			cboObj.SelectedValue = m_ActiveObj;
			cboObj_SelectedIndexChanged(cboObj, new EventArgs());

			cboRM.Visible = false;
			cboObj.Visible = false;

			m_IsLoad = false;
		}

		private void cboRM_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (!m_IsLoad)
			{
				if (cboRM.SelectedIndex > -1)
				{

					m_ActiveVrsta = Convert.ToInt32(cboRM.SelectedValue.ToString());
					m_ActiveObj = 0;

					m_Error = null;
					//Dim tt As DataTable = DB.GetData("SELECT * FROM Moze(" + cboRM.SelectedValue.ToString + ")", m_Error)
					DataTable tt = SrednjiSloj.Pravila.VratiViewButtons(Convert.ToInt32(cboRM.SelectedValue), ref m_Error);
					if (m_Error == null)
					{
						if (tt.Rows.Count > 0)
						{

						}
					}
					else
					{
						MessageBox.Show(m_Error);
						return;
					}

					lblObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
					cboObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
					Label1.Visible = false; //(cboRM.SelectedValue < 3)

					if (Convert.ToInt32(cboRM.SelectedValue) == 1)
					{
						lblObj.Text = "Knjižara";
						cboObj.ValueMember = "objid";
						cboObj.DisplayMember = "naziv";
						string gr = null;
						cboObj.DataSource = SrednjiSloj.Pravila.VratiKnjizareZaMagacin(0, ref gr);
					}
					else if (Convert.ToInt32(cboRM.SelectedValue) == 2)
					{
						lblObj.Text = "Magacin";
						cboObj.ValueMember = "objid";
						cboObj.DisplayMember = "naziv";
						string gr = null;
						cboObj.DataSource = SrednjiSloj.Pravila.VratiSpisakMagacina(ref gr);
					}
					else if (Convert.ToInt32(cboRM.SelectedValue) > 2)
					{
						//m_Stanje = SrednjiSloj.Pravila.ViewData(m_ActiveObj, m_ActiveVrsta, m_Error)
						//m_Stanje = DB.GetData("SELECT * FROM PrometZa(" + cboRM.SelectedValue.ToString + ")", m_Error)
						//dgStanje.DataSource = m_Stanje
					}
				}
			}
		}

		private void cboObj_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (!m_IsLoad)
			{
				if (Convert.ToInt32(cboRM.SelectedValue) == 1)
				{
					//m_Stanje = DB.GetData("SELECT * FROM Stanje(" + cboObj.SelectedValue.ToString + ")", m_Error)
					m_ActiveObj = Convert.ToInt32(cboObj.SelectedValue);
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 2)
				{
					//m_Stanje = DB.GetData("SELECT * FROM Stanje(" + cboObj.SelectedValue.ToString + ")", m_Error)
					m_ActiveObj = Convert.ToInt32(cboObj.SelectedValue);

				}
				else if (Convert.ToInt32(cboRM.SelectedValue) > 2)
				{

				}

			}
		}

		private void ToolStripButton2_Click(System.Object sender, System.EventArgs e)
		{
			m_Stanje = SrednjiSloj.Pravila.VratiListuDokumenata(m_ActiveObj, m_ActiveVrsta, dtpOdDana.Value, dtpDoDana.Value, ref m_Error);
			dgStanje.DataSource = m_Stanje;
			dgStanje.Columns[5].DefaultCellStyle.Format = "N2";
			dgStanje.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
		}

		private void ToolStripButton1_Click(System.Object sender, System.EventArgs e)
		{
			List<int> tot = new List<int>();
			List<string> l = new List<string>();
			tot.Add(5);
			if (cboObj.Visible)
			{
				l.Add("Dnevnik rada za " + cboObj.Text + " za period " + dtpOdDana.Value.ToString("dd.MM.yyy") + " - " + dtpDoDana.Value.ToString("dd.MM.yyyy"));
			}
			else
			{
				l.Add("Dnevnik rada za period " + dtpOdDana.Value.ToString("dd.MM.yyy") + " - " + dtpDoDana.Value.ToString("dd.MM.yyyy") + " (" + cboRM.Text + ")");
			}
			modMain.ExportToExcel(l, dgStanje, "Dnevnik", null, Application.StartupPath + "\\" + l[0] + ".xlsx", 0, 0, tot);


		}

		private void lblObj_Click(System.Object sender, System.EventArgs e)
		{

		}
	}
}