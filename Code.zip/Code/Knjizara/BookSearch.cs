﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class BookSearch
	{
		public BookSearch()
		{
			InitializeComponent();
		}

		private DataTable m_Data;
		private string m_Error = null;

		public delegate void ChosenEventHandler(DataGridViewRow Result);
		public event ChosenEventHandler Chosen;

		public void Init()
		{
			//m_Data = DB.GetData("SELECT * FROM Knjige", m_Error)
			m_Data = SrednjiSloj.Pravila.VratiSpisakKnjiga(ref m_Error);
			dgData.DataSource = m_Data;

			dgData.Columns[0].Visible = false;
			dgData.Columns[1].HeaderText = "ISBN";
			dgData.Columns[2].HeaderText = "Naslov";
			dgData.Columns[3].HeaderText = "Autor";
			dgData.Columns[4].HeaderText = "Godina";
			dgData.Columns[5].HeaderText = "Cena";

			dgData.Columns[5].DefaultCellStyle.Format = "N2";
			dgData.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
		}

		private void txtSearch_TextChanged(System.Object sender, System.EventArgs e)
		{
			string f = "Naslov like '%" + txtSearch.Text + "%'";
			m_Data.DefaultView.RowFilter = f;
		}

		private void dgData_DoubleClick(object sender, System.EventArgs e)
		{
			if (Chosen != null)
				Chosen(dgData.CurrentRow);
		}
	}

}