﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmKnjiga : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKnjiga));
			this.Label1 = new System.Windows.Forms.Label();
			this.txtISBN = new System.Windows.Forms.TextBox();
			this.txtNaslov = new System.Windows.Forms.TextBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.txtAutor = new System.Windows.Forms.TextBox();
			this.Label3 = new System.Windows.Forms.Label();
			this.txtGodina = new System.Windows.Forms.TextBox();
			this.Label4 = new System.Windows.Forms.Label();
			this.txtCena = new System.Windows.Forms.TextBox();
			this.Label5 = new System.Windows.Forms.Label();
			this.Button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			//
			//Label1
			//
			this.Label1.AutoSize = true;
			this.Label1.Location = new System.Drawing.Point(12, 9);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(32, 13);
			this.Label1.TabIndex = 0;
			this.Label1.Text = "ISBN";
			//
			//txtISBN
			//
			this.txtISBN.Location = new System.Drawing.Point(67, 6);
			this.txtISBN.Name = "txtISBN";
			this.txtISBN.Size = new System.Drawing.Size(222, 20);
			this.txtISBN.TabIndex = 1;
			//
			//txtNaslov
			//
			this.txtNaslov.Location = new System.Drawing.Point(67, 32);
			this.txtNaslov.Multiline = true;
			this.txtNaslov.Name = "txtNaslov";
			this.txtNaslov.Size = new System.Drawing.Size(222, 51);
			this.txtNaslov.TabIndex = 3;
			//
			//Label2
			//
			this.Label2.AutoSize = true;
			this.Label2.Location = new System.Drawing.Point(12, 35);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(40, 13);
			this.Label2.TabIndex = 2;
			this.Label2.Text = "Naslov";
			//
			//txtAutor
			//
			this.txtAutor.Location = new System.Drawing.Point(67, 89);
			this.txtAutor.Name = "txtAutor";
			this.txtAutor.Size = new System.Drawing.Size(222, 20);
			this.txtAutor.TabIndex = 5;
			//
			//Label3
			//
			this.Label3.AutoSize = true;
			this.Label3.Location = new System.Drawing.Point(12, 92);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(32, 13);
			this.Label3.TabIndex = 4;
			this.Label3.Text = "Autor";
			//
			//txtGodina
			//
			this.txtGodina.Location = new System.Drawing.Point(67, 115);
			this.txtGodina.MaxLength = 4;
			this.txtGodina.Name = "txtGodina";
			this.txtGodina.Size = new System.Drawing.Size(58, 20);
			this.txtGodina.TabIndex = 7;
			//
			//Label4
			//
			this.Label4.AutoSize = true;
			this.Label4.Location = new System.Drawing.Point(12, 118);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(41, 13);
			this.Label4.TabIndex = 6;
			this.Label4.Text = "Godina";
			//
			//txtCena
			//
			this.txtCena.Location = new System.Drawing.Point(180, 115);
			this.txtCena.Name = "txtCena";
			this.txtCena.Size = new System.Drawing.Size(109, 20);
			this.txtCena.TabIndex = 9;
			this.txtCena.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			//
			//Label5
			//
			this.Label5.AutoSize = true;
			this.Label5.Location = new System.Drawing.Point(142, 118);
			this.Label5.Name = "Label5";
			this.Label5.Size = new System.Drawing.Size(32, 13);
			this.Label5.TabIndex = 8;
			this.Label5.Text = "Cena";
			//
			//Button1
			//
			this.Button1.Image = (System.Drawing.Image)resources.GetObject("Button1.Image");
			this.Button1.Location = new System.Drawing.Point(111, 164);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(75, 23);
			this.Button1.TabIndex = 10;
			this.Button1.UseVisualStyleBackColor = true;
			//
			//frmKnjiga
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(295, 188);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.txtCena);
			this.Controls.Add(this.Label5);
			this.Controls.Add(this.txtGodina);
			this.Controls.Add(this.Label4);
			this.Controls.Add(this.txtAutor);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.txtNaslov);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.txtISBN);
			this.Controls.Add(this.Label1);
			this.Name = "frmKnjiga";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Knjiga";
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmKnjiga_Load);
			Button1.Click += new System.EventHandler(Button1_Click);
		}
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtISBN;
		internal System.Windows.Forms.TextBox txtNaslov;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.TextBox txtAutor;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtGodina;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.TextBox txtCena;
		internal System.Windows.Forms.Label Label5;
		internal System.Windows.Forms.Button Button1;
	}

}