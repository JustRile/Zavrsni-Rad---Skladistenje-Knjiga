﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmIzbor
	{
		public frmIzbor()
		{
			InitializeComponent();
		}

		private DataGridViewRow m_Row;

		public DataGridViewRow Result
		{
			get
			{
				return m_Row;
			}
		}

		private void frmIzbor_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			BookSearch1.Init();
		}


		private void BookSearch1_Chosen(System.Windows.Forms.DataGridViewRow Result)
		{
			m_Row = Result;
			this.Close();
		}

		private void BookSearch1_Load(System.Object sender, System.EventArgs e)
		{

		}

		private void mnuAdd_Click(System.Object sender, System.EventArgs e)
		{
			frmKnjiga f = new frmKnjiga();
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
			BookSearch1.Init();
		}
	}
}