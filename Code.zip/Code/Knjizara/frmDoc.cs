﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmDoc
	{
		public frmDoc()
		{
			InitializeComponent();
		}

		private string m_Error = null;
		private int m_DocID;
		private bool m_IsLocked;
		private int m_VrstaDoc;
		private int m_Vrsta;
		private int m_ObjID;
		private int m_VrstaU;
		private int m_ObjU;
		private string m_Caption;
        private DataTable m_Data;

		public void InitData(ref DataTable _Data)
		{
			m_Data = _Data;
		}

		public void Init(int _VrstaDoc, int _Vrsta, int _ObjID, int _VrstaU, int _ObjU, string _Caption)
		{
			m_VrstaDoc = _VrstaDoc;
			m_Vrsta = _Vrsta;
			m_ObjID = _ObjID;
			m_VrstaU = _VrstaU;
			m_ObjU = _ObjU;
			m_Caption = _Caption;
		}

		public void Init(int _DocID, string _Caption, bool _IsLocked = false)
		{
			m_DocID = _DocID;
			m_Caption = _Caption;
			m_IsLocked = _IsLocked;
		}

		private void frmDoc_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;

			if (m_Data == null)
			{
				//m_Data = DB.GetData("select * from DocStavke(" + m_DocID.ToString + ")", m_Error)
				m_Data = SrednjiSloj.Pravila.VratiStavkeDokumenta(m_DocID, ref m_Error);
			}
			if (m_Error == null)
			{
				dgData.DataSource = m_Data;
				dgData.Columns[0].Visible = false;
				dgData.Columns[1].Visible = false;
				dgData.Columns[2].ReadOnly = true;
				dgData.Columns[3].ReadOnly = true;
				dgData.Columns[4].ReadOnly = true;
				dgData.Columns[5].ReadOnly = true;
				dgData.Columns[6].ReadOnly = true;
				dgData.Columns[6].DefaultCellStyle.Format = "N2";
				dgData.AllowUserToAddRows = false;
			}
			if (m_IsLocked)
			{
				dgData.ReadOnly = true;
				dgData.AllowUserToDeleteRows = false;
			}
			else
			{
				dgData.ContextMenuStrip = ContextMenuStrip1;
			}
			this.Text = m_Caption;
			int zbir = 0;
			if (m_Data != null)
			{
				if (m_Data.Rows.Count > 0)
				{
					zbir = Convert.ToInt32(m_Data.Compute("SUM(komada)", null));
					Button1.Visible = (zbir > 0);
				}
			}
		}

		private void mnuBookAdd_Click(System.Object sender, System.EventArgs e)
		{
			frmIzbor f = new frmIzbor();
			f.ShowDialog();
			DataGridViewRow dr = f.Result;
			if (dr != null)
			{
				DataRow r = m_Data.NewRow();
				r[0] = m_DocID;
				r[1] = dr.Cells["bookid"].Value;
				r[2] = dr.Cells["isbn"].Value.ToString();
				r[3] = dr.Cells["naslov"].Value.ToString();
				r[4] = dr.Cells["autor"].Value.ToString();
				r[5] = dr.Cells["godina"].Value;
				r[6] = dr.Cells["cena"].Value;
				r[7] = 0;
				m_Data.Rows.Add(r);
			}
		}

		private void Button1_Click(System.Object sender, System.EventArgs e)
		{
			bool ok = true;
			if (!(m_Vrsta == 2 && m_VrstaU == 2))
			{
				foreach (DataRow r in m_Data.Rows)
				{
					if (Convert.ToInt32(r["komada"].ToString()) == 0)
					{
						MessageBox.Show("Mora se uneti broj knjiga veče od 0.", "Pogrešan unos");
						ok = false;
						break;
					}
				}
			}
			if (ok)
			{
				m_Error = null;
				int broj = 0;
				string oznaka = "";
				if (SrednjiSloj.Pravila.ObradaDokumenta(ref m_DocID, m_VrstaDoc, m_ObjID, m_Vrsta, m_ObjU, m_VrstaU, DateTime.Today, ref broj, ref oznaka, 0M, "1", ref m_Error))
				{
					foreach (DataRow r in m_Data.Rows)
					{
						m_Error = null;
						if (SrednjiSloj.Pravila.EvidentirajPromet(m_DocID, Convert.ToInt32(r["bookid"]), Convert.ToInt32(r["komada"]), ref m_Error))
						{

						}
						else
						{
							MessageBox.Show(m_Error);
						}
					}
					m_Error = null;
					if (SrednjiSloj.Pravila.AzurIznos(m_DocID, ref m_Error))
					{
						if (m_VrstaDoc == 4)
						{
							int origdocid = Convert.ToInt32(dgData.Rows[0].Cells["docid"].Value);
							SrednjiSloj.Pravila.PoveziDokumenta(origdocid, m_DocID, 2, ref m_Error);
							SrednjiSloj.Pravila.MakeReklamacija(origdocid, ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(origdocid, "2", ref m_Error);
						}
						else if (m_VrstaDoc == 5)
						{
							int origdocid = Convert.ToInt32(dgData.Rows[0].Cells["docid"].Value);
							SrednjiSloj.Pravila.PoveziDokumenta(origdocid, m_DocID, 3, ref m_Error);
							SrednjiSloj.Pravila.JednaStrana(m_DocID, m_ObjID, m_Vrsta, -1, ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(origdocid, "2", ref m_Error);
						}
						else if (m_Vrsta == 2 && m_VrstaDoc == 1)
						{
							int origdocid = Convert.ToInt32(dgData.Rows[0].Cells["docid"].Value);
							SrednjiSloj.Pravila.PoveziDokumenta(origdocid, m_DocID, 1, ref m_Error);
							SrednjiSloj.Pravila.JednaStrana(m_DocID, m_ObjU, m_VrstaU, 1, ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(origdocid, "3", ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(m_DocID, "2", ref m_Error);

						}
						else if (m_Vrsta == 2 && m_VrstaDoc == 2)
						{
							//Dim s As String = "update Dokumenta set status = '3' where vrstadoc = 1 and status = '1' and obju = " + m_ObjID.ToString
							//DB.Execute(s, m_Error)
							SrednjiSloj.Pravila.UpdateStatusDokumenta("3", 1, "1", m_ObjID, ref m_Error);
						}
						else if (m_VrstaDoc == 3)
						{
							int origdocid = Convert.ToInt32(dgData.Rows[0].Cells["docid"].Value);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(origdocid, "2", ref m_Error);
						}
						else if (m_Vrsta == 1 && m_VrstaU == 1)
						{
							int origdocid = Convert.ToInt32(dgData.Rows[0].Cells["docid"].Value);
							SrednjiSloj.Pravila.PoveziDokumenta(origdocid, m_DocID, 1, ref m_Error);
							SrednjiSloj.Pravila.JednaStrana(m_DocID, m_ObjU, m_VrstaU, 1, ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(origdocid, "2", ref m_Error);
							SrednjiSloj.Pravila.UpdateStatusDokumenta(m_DocID, "2", ref m_Error);
						}
						MessageBox.Show("Podaci su uspešno uneti.");
						DialogResult = System.Windows.Forms.DialogResult.OK;
						this.Close();
					}
					else
					{
						MessageBox.Show(m_Error);
					}
				}
				else
				{
					MessageBox.Show("Podaci nisu uspešno unwti.", "GRŠKA");
					DialogResult = System.Windows.Forms.DialogResult.Cancel;
					this.Close();
				}
			}
		}

		private void dgData_CellContentClick(System.Object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
		{

		}

		private void m_Data_RowChanged(object sender, System.Data.DataRowChangeEventArgs e)
		{
			if (m_Vrsta == 2 && m_VrstaU == 2)
			{
                if ((int)e.Row["komada", DataRowVersion.Current] > (int)e.Row["komada", DataRowVersion.Original])
				{
					MessageBox.Show("Ne može se uneti veći broj nego što je poslato.", "ZLOUPOTREBA", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					e.Row["komada"] = e.Row["komada", DataRowVersion.Original];
				}
			}
			else if (m_Vrsta == 2 && m_VrstaU == 1)
			{
				if ((int)e.Row["komada", DataRowVersion.Current] > (int)e.Row["komada", DataRowVersion.Original])
				{
					MessageBox.Show("Ne može se uneti veća količina nego što je stanje knjiga u magacinu.", "ZLOUPOTREBA", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					e.Row["komada"] = e.Row["komada", DataRowVersion.Original];
				}
			}
		}

		private void ContextMenuStrip1_Opening(System.Object sender, System.ComponentModel.CancelEventArgs e)
		{

		}

        private void dgData_DoubleClick(object sender, EventArgs e)
        {
			if (!(dgData.CurrentRow == null))
			{
				frmInput f = new frmInput();
				if ((m_Vrsta == 2) && (m_VrstaU == 2))
				{
					f.Init("Knjige", "Unesite broj knjiga", true);
				}
				else
				{
					f.Init("Knjige", "Unesite broj knjiga");
				}
				f.ShowDialog();
				if (f.DialogResult == DialogResult.OK)
				{
					if ((m_Vrsta == 2) && (m_VrstaU == 2))
					{
						if (Convert.ToInt32(f.Result) > Convert.ToInt32(dgData.CurrentRow.Cells[7].Value.ToString()))
						{
							MessageBox.Show("Ne može se primiti više knjiga od poslatih.", "Pogrešan unos");
						}
						else { dgData.CurrentRow.Cells["komada"].Value = Convert.ToInt32(f.Result); }
					}
					else { dgData.CurrentRow.Cells["komada"].Value = Convert.ToInt32(f.Result); }

				}

				f.Close();
				f.Dispose();
				f = null;
			}
		}
    }
}