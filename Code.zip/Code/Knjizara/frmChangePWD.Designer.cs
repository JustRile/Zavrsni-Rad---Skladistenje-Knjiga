﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmChangePWD : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			this.txtPWD = new System.Windows.Forms.TextBox();
			this.PasswordLabel = new System.Windows.Forms.Label();
			this.TextBox1 = new System.Windows.Forms.TextBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.Cancel = new System.Windows.Forms.Button();
			this.OK = new System.Windows.Forms.Button();
			this.SuspendLayout();
			//
			//txtPWD
			//
			this.txtPWD.Location = new System.Drawing.Point(117, 12);
			this.txtPWD.Name = "txtPWD";
			this.txtPWD.PasswordChar = (char)42;
			this.txtPWD.Size = new System.Drawing.Size(155, 20);
			this.txtPWD.TabIndex = 5;
			//
			//PasswordLabel
			//
			this.PasswordLabel.BackColor = System.Drawing.Color.Transparent;
			this.PasswordLabel.ForeColor = System.Drawing.Color.White;
			this.PasswordLabel.Location = new System.Drawing.Point(5, 12);
			this.PasswordLabel.Name = "PasswordLabel";
			this.PasswordLabel.Size = new System.Drawing.Size(96, 23);
			this.PasswordLabel.TabIndex = 4;
			this.PasswordLabel.Text = "New Password";
			this.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			//TextBox1
			//
			this.TextBox1.Location = new System.Drawing.Point(117, 38);
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.PasswordChar = (char)42;
			this.TextBox1.Size = new System.Drawing.Size(155, 20);
			this.TextBox1.TabIndex = 7;
			//
			//Label1
			//
			this.Label1.BackColor = System.Drawing.Color.Transparent;
			this.Label1.ForeColor = System.Drawing.Color.White;
			this.Label1.Location = new System.Drawing.Point(5, 38);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(106, 23);
			this.Label1.TabIndex = 6;
			this.Label1.Text = "Repeated password";
			this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			//Cancel
			//
			this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.Cancel.ForeColor = System.Drawing.Color.White;
			this.Cancel.Location = new System.Drawing.Point(287, 36);
			this.Cancel.Name = "Cancel";
			this.Cancel.Size = new System.Drawing.Size(94, 23);
			this.Cancel.TabIndex = 9;
			this.Cancel.Text = "&Cancel";
			//
			//OK
			//
			this.OK.ForeColor = System.Drawing.Color.White;
			this.OK.Location = new System.Drawing.Point(287, 9);
			this.OK.Name = "OK";
			this.OK.Size = new System.Drawing.Size(94, 23);
			this.OK.TabIndex = 8;
			this.OK.Text = "&OK";
			//
			//frmChangePWD
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(387, 69);
			this.Controls.Add(this.Cancel);
			this.Controls.Add(this.OK);
			this.Controls.Add(this.TextBox1);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.txtPWD);
			this.Controls.Add(this.PasswordLabel);
			this.Name = "frmChangePWD";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Promena lozinke";
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmChangePWD_Load);
			OK.Click += new System.EventHandler(OK_Click);
		}
		internal System.Windows.Forms.TextBox txtPWD;
		internal System.Windows.Forms.Label PasswordLabel;
		internal System.Windows.Forms.TextBox TextBox1;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Button Cancel;
		internal System.Windows.Forms.Button OK;
	}

}