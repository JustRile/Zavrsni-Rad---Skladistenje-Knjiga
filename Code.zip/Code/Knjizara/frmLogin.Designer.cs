﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmLogin : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}
		internal System.Windows.Forms.Label UsernameLabel;
		internal System.Windows.Forms.Label PasswordLabel;
		internal System.Windows.Forms.TextBox txtUser;
		internal System.Windows.Forms.TextBox txtPWD;
		internal System.Windows.Forms.Button OK;
		internal System.Windows.Forms.Button Cancel;

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
			this.UsernameLabel = new System.Windows.Forms.Label();
			this.PasswordLabel = new System.Windows.Forms.Label();
			this.txtUser = new System.Windows.Forms.TextBox();
			this.txtPWD = new System.Windows.Forms.TextBox();
			this.OK = new System.Windows.Forms.Button();
			this.Cancel = new System.Windows.Forms.Button();
			this.LogoPictureBox = new System.Windows.Forms.PictureBox();
			this.Label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)this.LogoPictureBox).BeginInit();
			this.SuspendLayout();
			//
			//UsernameLabel
			//
			this.UsernameLabel.BackColor = System.Drawing.Color.Transparent;
			this.UsernameLabel.ForeColor = System.Drawing.Color.White;
			this.UsernameLabel.Location = new System.Drawing.Point(188, 48);
			this.UsernameLabel.Name = "UsernameLabel";
			this.UsernameLabel.Size = new System.Drawing.Size(96, 23);
			this.UsernameLabel.TabIndex = 0;
			this.UsernameLabel.Text = "&User name";
			this.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			//PasswordLabel
			//
			this.PasswordLabel.BackColor = System.Drawing.Color.Transparent;
			this.PasswordLabel.ForeColor = System.Drawing.Color.White;
			this.PasswordLabel.Location = new System.Drawing.Point(188, 83);
			this.PasswordLabel.Name = "PasswordLabel";
			this.PasswordLabel.Size = new System.Drawing.Size(96, 23);
			this.PasswordLabel.TabIndex = 2;
			this.PasswordLabel.Text = "&Password";
			this.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			//txtUser
			//
			this.txtUser.Location = new System.Drawing.Point(300, 50);
			this.txtUser.Name = "txtUser";
			this.txtUser.Size = new System.Drawing.Size(155, 20);
			this.txtUser.TabIndex = 1;
			//
			//txtPWD
			//
			this.txtPWD.Location = new System.Drawing.Point(300, 83);
			this.txtPWD.Name = "txtPWD";
			this.txtPWD.PasswordChar = (char)42;
			this.txtPWD.Size = new System.Drawing.Size(155, 20);
			this.txtPWD.TabIndex = 3;
			//
			//OK
			//
			this.OK.ForeColor = System.Drawing.Color.White;
			this.OK.Location = new System.Drawing.Point(191, 147);
			this.OK.Name = "OK";
			this.OK.Size = new System.Drawing.Size(94, 23);
			this.OK.TabIndex = 4;
			this.OK.Text = "&OK";
			//
			//Cancel
			//
			this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.Cancel.ForeColor = System.Drawing.Color.White;
			this.Cancel.Location = new System.Drawing.Point(300, 147);
			this.Cancel.Name = "Cancel";
			this.Cancel.Size = new System.Drawing.Size(94, 23);
			this.Cancel.TabIndex = 5;
			this.Cancel.Text = "&Cancel";
			//
			//LogoPictureBox
			//
			this.LogoPictureBox.Image = (System.Drawing.Image)resources.GetObject("LogoPictureBox.Image");
			this.LogoPictureBox.Location = new System.Drawing.Point(-1, -1);
			this.LogoPictureBox.Name = "LogoPictureBox";
			this.LogoPictureBox.Size = new System.Drawing.Size(295, 195);
			this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.LogoPictureBox.TabIndex = 0;
			this.LogoPictureBox.TabStop = false;
			//
			//Label1
			//
			this.Label1.BackColor = System.Drawing.Color.Transparent;
			this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, (byte)238);
			this.Label1.ForeColor = System.Drawing.Color.White;
			this.Label1.Location = new System.Drawing.Point(188, 9);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(258, 23);
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Šta čitaš, tako misliš ...";
			this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			//frmLogin
			//
			this.AcceptButton = this.OK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.CancelButton = this.Cancel;
			this.ClientSize = new System.Drawing.Size(458, 192);
			this.Controls.Add(this.Cancel);
			this.Controls.Add(this.OK);
			this.Controls.Add(this.txtPWD);
			this.Controls.Add(this.txtUser);
			this.Controls.Add(this.PasswordLabel);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.UsernameLabel);
			this.Controls.Add(this.LogoPictureBox);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmLogin";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Prijavljivanje";
			((System.ComponentModel.ISupportInitialize)this.LogoPictureBox).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			OK.Click += new System.EventHandler(OK_Click);
			Cancel.Click += new System.EventHandler(Cancel_Click);
			base.Load += new System.EventHandler(frmLogin_Load);
		}
		internal System.Windows.Forms.PictureBox LogoPictureBox;
		internal System.Windows.Forms.Label Label1;

	}

}