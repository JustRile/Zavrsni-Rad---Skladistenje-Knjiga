﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;
using System.Xml;

namespace Knjizara
{
	public partial class Form1
	{
		public Form1()
		{
			InitializeComponent();
		}

		private int m_EmpID; //id radnika koji je prijavljen
		private int m_Vrsta; //0-knjizara,1-magacin,2-dobavljac,3-finansije,4-uprava
		private int m_ID; //id datog objekta
		private Dictionary<Point, string> m_Natpisi;

		public Dictionary<Point, string> CaptionList
		{
			get
			{
				if (m_Natpisi == null)
				{
					LoadNatpise();
				}
				return m_Natpisi;
			}
		}

		public int EmpID
		{
			get
			{
				return m_EmpID;
			}
		}

		public int RM
		{
			get
			{
				return m_Vrsta;
			}
		}

		public int ObjID
		{
			get
			{
				return m_ID;
			}
		}

		private void Form1_Load(System.Object sender, System.EventArgs e)
		{


			//m_EmpID = 1
			//SrednjiSloj.Pravila.EmpID = 1

		}

		private void ZaposleniToolStripMenuItem_Click(System.Object sender, System.EventArgs e)
		{
			frmZaposleni f = new frmZaposleni();
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void ObjekatiToolStripMenuItem_Click(System.Object sender, System.EventArgs e)
		{
			frmObjekti f = new frmObjekti();
			f.Init(1);
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void mnuMagacini_Click(System.Object sender, System.EventArgs e)
		{
			frmObjekti f = new frmObjekti();
			f.Init(2);
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void mnuPromet_Click(System.Object sender, System.EventArgs e)
		{
			frmPromet f = new frmPromet();
			f.MdiParent = this;
			f.Show();
			f.Left = 0;
			f.Top = 0;
		}

		private void PreglediToolStripMenuItem_Click(System.Object sender, System.EventArgs e)
		{
			frmPregled f = new frmPregled();
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void Form1_Shown(object sender, System.EventArgs e)
		{
			this.Hide();


			bool flag = false;
			string usePrijavu = "";
			if (m_Vrsta == 0)
			{
				try
				{
					XmlDocument doc = new XmlDocument();
					doc.Load("Knjizara.exe.config");
					XmlNode MyRootNode = doc.SelectSingleNode("//configuration//applicationSettings//Knjizara.My.MySettings"); //Here you need to change the YourProjectName
					XmlNodeList keyNodes = MyRootNode.SelectNodes(".//setting");
					foreach (XmlNode keyNode in keyNodes)
					{
						if (keyNode.Attributes["name"].Value == "KoristiPrijavu")
						{
							flag = true;
							usePrijavu = keyNode.InnerText;
							break;
						}
						else
						{
						}
					}
					//If (flag) Then
					//    MessageBox.Show("has a setting four " & ctrl.Name)
					//Else
					//    MessageBox.Show("Not a setting - the name is " & ctrl.Name)
					//End If
				}
				catch (Exception ex)
				{
					Debug.Print(ex.Message);
					MessageBox.Show(ex.Message);
				}
			}

			if (!flag)
			{
				if (DateTime.Today > new DateTime(2022, 6, 14))
				{
					MessageBox.Show("Probni period je istekao.");
					System.Environment.Exit(1);
				}
			}
			else
			{
				if (usePrijavu == "1")
				{
					frmLogin f = new frmLogin();
					f.ShowDialog();
					f.Close();
					f.Dispose();
					f = null;

					if (SrednjiSloj.Pravila.EmpID == 0)
					{
						System.Environment.Exit(1);
					}

				}
				else
				{
					SrednjiSloj.Pravila.EmpID = 1;
					m_Vrsta = 0;
					//End
				}


				string m_Error = null;
				try
				{
					//Dim h As DataTable = DB.GetData("SELECT * FROM Zaposleni WHERE empid = " + SrednjiSloj.Pravila.EmpID.ToString, m_Error)
					DataTable h = SrednjiSloj.Pravila.VratiPodatkeOPrijavljenomKorisniku(ref m_Error);
					lblRadnik.Text = h.Rows[0]["ime"].ToString();

					m_Vrsta = Convert.ToInt32(h.Rows[0]["vrsta"]);
					m_ID = Convert.ToInt32(h.Rows[0]["objid"]);
					mnuProdaja2.Visible = (m_Vrsta == 1);

					//h = DB.GetData("SELECT naziv from VrstaRM where vrsta = " + m_Vrsta.ToString, m_Error)
					h = SrednjiSloj.Pravila.VrstaRMInfo(m_Vrsta, ref m_Error);

					if (h.Rows.Count > 0)
					{
						lblRM.Text = h.Rows[0]["naziv"].ToString();

						if (m_ID > 0)
						{
							//h = DB.GetData("SELECT naziv from Objekti where objid = " + m_ID.ToString, m_Error)
							h = SrednjiSloj.Pravila.VratiObjekatInfo(m_ID, ref m_Error);
							lblObj.Text = h.Rows[0]["naziv"].ToString();
						}
						else
						{
							if (m_Vrsta == 3)
							{
								lblObj.Text = "Služba za finansije";
							}
							else if (m_Vrsta == 4)
							{
								lblObj.Text = "Uprava";
							}
							else if (m_Vrsta == 5)
							{
								lblObj.Text = "Dobavljač";
							}
						}

						try
						{
							XmlDocument doc = new XmlDocument();
							doc.Load("Knjizara.exe.config");
							XmlNode MyRootNode = doc.SelectSingleNode("//configuration//applicationSettings//Knjizara.My.MySettings"); //Here you need to change the YourProjectName
							XmlNodeList keyNodes = MyRootNode.SelectNodes(".//setting");
							foreach (XmlNode keyNode in keyNodes)
							{
								if (keyNode.Attributes["name"].Value == "HideMenu")
								{
									flag = true;
									mnuAktivnosti.Visible = false;
									break;
								}
								else
								{
								}
							}
							//If (flag) Then
							//    MessageBox.Show("has a setting four " & ctrl.Name)
							//Else
							//    MessageBox.Show("Not a setting - the name is " & ctrl.Name)
							//End If
						}
						catch (Exception ex)
						{
							Debug.Print(ex.Message);
						}
					}
					else
					{
						lblRM.Text = "Prezentacija " + DateTime.Today.Year.ToString();
						lblRadnik.Text = "Admin";
						lblObj.Text = "";
						mnuAktiv2.Visible = false;
					}
					this.Show();
				}
				catch (Exception exMain)
				{
					MessageBox.Show(exMain.Message);
				}
			}
			LoadNatpise();
		}

		private void LoadNatpise()
		{
			if (System.IO.File.Exists(Application.StartupPath + "\\Natpisi.txt"))
			{
				System.IO.StreamReader f = new System.IO.StreamReader(Application.StartupPath + "\\Natpisi.txt", System.Text.UnicodeEncoding.Default);
				m_Natpisi = new Dictionary<Point, string>();
				f.ReadLine();
				while (f.Peek() != -1)
				{
					string sline = f.ReadLine();
					string[] arr = sline.Split(Convert.ToChar(","));
					Point key = new Point(Convert.ToInt32(arr[0]), Convert.ToInt32(arr[1]));
					m_Natpisi.Add(key, arr[2]);
				}
				f.Close();
				f.Dispose();
				f = null;
			}
		}
		private void mnuPregled2_Click(System.Object sender, System.EventArgs e)
		{
			frmPregled2 f = new frmPregled2();
			if (SrednjiSloj.Pravila.EmpID > 1)
			{
				f.Init(m_Vrsta, m_ID);
			}
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void mnuPromet2_Click(System.Object sender, System.EventArgs e)
		{
			frmPromet2 f = new frmPromet2();
			if (SrednjiSloj.Pravila.EmpID > 1)
			{

			}
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void mnuAktivnosti_Click(System.Object sender, System.EventArgs e)
		{

		}

		private void mnuProdaja_Click(System.Object sender, System.EventArgs e)
		{
			frmProdaja f = new frmProdaja();
			f.Init(0);
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private void mnuProdaja2_Click(System.Object sender, System.EventArgs e)
		{
			if (m_Vrsta == 1)
			{
				frmProdaja f = new frmProdaja();
				f.Init(this.ObjID);
				f.ShowDialog();
				f.Close();
				f.Dispose();
				f = null;
			}
		}

		private void mnuKnjige_Click(System.Object sender, System.EventArgs e)
		{
			frmIzbor f = new frmIzbor();
			f.ShowDialog();
			f.Close();
			f.Dispose();
			f = null;
		}

		private static Form1 _DefaultInstance;
		public static Form1 DefaultInstance
		{
			get
			{
				if (_DefaultInstance == null || _DefaultInstance.IsDisposed)
					_DefaultInstance = new Form1();

				return _DefaultInstance;
			}
		}
	}

}