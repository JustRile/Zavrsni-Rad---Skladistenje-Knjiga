﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmPregled : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPregled));
			this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
			this.ToolStripButton1 = new System.Windows.Forms.ToolStripButton();
			this.cboObj = new System.Windows.Forms.ComboBox();
			this.lblObj = new System.Windows.Forms.Label();
			this.cboRM = new System.Windows.Forms.ComboBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.dtpOdDana = new System.Windows.Forms.DateTimePicker();
			this.dtpDoDana = new System.Windows.Forms.DateTimePicker();
			this.Label3 = new System.Windows.Forms.Label();
			this.dgStanje = new System.Windows.Forms.DataGridView();
			this.ToolStripButton2 = new System.Windows.Forms.ToolStripButton();
			this.ToolStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dgStanje).BeginInit();
			this.SuspendLayout();
			//
			//ToolStrip1
			//
			this.ToolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.ToolStripButton2, this.ToolStripButton1});
			this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
			this.ToolStrip1.Name = "ToolStrip1";
			this.ToolStrip1.Size = new System.Drawing.Size(491, 39);
			this.ToolStrip1.TabIndex = 0;
			this.ToolStrip1.Text = "ToolStrip1";
			//
			//ToolStripButton1
			//
			this.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton1.Image = (System.Drawing.Image)resources.GetObject("ToolStripButton1.Image");
			this.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.ToolStripButton1.Name = "ToolStripButton1";
			this.ToolStripButton1.Size = new System.Drawing.Size(36, 36);
			this.ToolStripButton1.Text = "ToolStripButton1";
			//
			//cboObj
			//
			this.cboObj.FormattingEnabled = true;
			this.cboObj.Location = new System.Drawing.Point(94, 67);
			this.cboObj.Name = "cboObj";
			this.cboObj.Size = new System.Drawing.Size(195, 21);
			this.cboObj.TabIndex = 16;
			this.cboObj.Visible = false;
			//
			//lblObj
			//
			this.lblObj.AutoSize = true;
			this.lblObj.Location = new System.Drawing.Point(12, 75);
			this.lblObj.Name = "lblObj";
			this.lblObj.Size = new System.Drawing.Size(44, 13);
			this.lblObj.TabIndex = 15;
			this.lblObj.Text = "Objekat";
			this.lblObj.Visible = false;
			//
			//cboRM
			//
			this.cboRM.FormattingEnabled = true;
			this.cboRM.Location = new System.Drawing.Point(94, 40);
			this.cboRM.Name = "cboRM";
			this.cboRM.Size = new System.Drawing.Size(195, 21);
			this.cboRM.TabIndex = 14;
			//
			//Label1
			//
			this.Label1.AutoSize = true;
			this.Label1.Location = new System.Drawing.Point(12, 48);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(76, 13);
			this.Label1.TabIndex = 13;
			this.Label1.Text = "Vrsta korisnika";
			//
			//Label2
			//
			this.Label2.AutoSize = true;
			this.Label2.Location = new System.Drawing.Point(311, 43);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(48, 13);
			this.Label2.TabIndex = 17;
			this.Label2.Text = "Od dana";
			//
			//dtpOdDana
			//
			this.dtpOdDana.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpOdDana.Location = new System.Drawing.Point(366, 40);
			this.dtpOdDana.Name = "dtpOdDana";
			this.dtpOdDana.Size = new System.Drawing.Size(118, 20);
			this.dtpOdDana.TabIndex = 18;
			//
			//dtpDoDana
			//
			this.dtpDoDana.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpDoDana.Location = new System.Drawing.Point(366, 68);
			this.dtpDoDana.Name = "dtpDoDana";
			this.dtpDoDana.Size = new System.Drawing.Size(118, 20);
			this.dtpDoDana.TabIndex = 20;
			//
			//Label3
			//
			this.Label3.AutoSize = true;
			this.Label3.Location = new System.Drawing.Point(311, 71);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(48, 13);
			this.Label3.TabIndex = 19;
			this.Label3.Text = "Do dana";
			//
			//dgStanje
			//
			this.dgStanje.AllowUserToAddRows = false;
			this.dgStanje.AllowUserToDeleteRows = false;
			this.dgStanje.Anchor = (System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right);
			this.dgStanje.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.dgStanje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgStanje.Location = new System.Drawing.Point(15, 91);
			this.dgStanje.Name = "dgStanje";
			this.dgStanje.ReadOnly = true;
			this.dgStanje.Size = new System.Drawing.Size(469, 195);
			this.dgStanje.TabIndex = 21;
			//
			//ToolStripButton2
			//
			this.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ToolStripButton2.Image = (System.Drawing.Image)resources.GetObject("ToolStripButton2.Image");
			this.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.ToolStripButton2.Name = "ToolStripButton2";
			this.ToolStripButton2.Size = new System.Drawing.Size(36, 36);
			this.ToolStripButton2.Text = "ToolStripButton2";
			//
			//frmPregled
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(491, 298);
			this.Controls.Add(this.dgStanje);
			this.Controls.Add(this.dtpDoDana);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.dtpOdDana);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.cboObj);
			this.Controls.Add(this.lblObj);
			this.Controls.Add(this.cboRM);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.ToolStrip1);
			this.Name = "frmPregled";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Dnevnik rada";
			this.ToolStrip1.ResumeLayout(false);
			this.ToolStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dgStanje).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmPregled_Load);
			cboRM.SelectedIndexChanged += new System.EventHandler(cboRM_SelectedIndexChanged);
			cboObj.SelectedIndexChanged += new System.EventHandler(cboObj_SelectedIndexChanged);
			ToolStripButton2.Click += new System.EventHandler(ToolStripButton2_Click);
			ToolStripButton1.Click += new System.EventHandler(ToolStripButton1_Click);
		}
		internal System.Windows.Forms.ToolStrip ToolStrip1;
		internal System.Windows.Forms.ToolStripButton ToolStripButton1;
		internal System.Windows.Forms.ComboBox cboObj;
		internal System.Windows.Forms.Label lblObj;
		internal System.Windows.Forms.ComboBox cboRM;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.DateTimePicker dtpOdDana;
		internal System.Windows.Forms.DateTimePicker dtpDoDana;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.DataGridView dgStanje;
		internal System.Windows.Forms.ToolStripButton ToolStripButton2;
	}

}