﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmProdaja
	{
		public frmProdaja()
		{
			InitializeComponent();
		}

		private int m_ObjID;
		private DataTable m_Magacini;
		private DataTable _m_Data;
		private DataTable m_Data
		{
			[System.Diagnostics.DebuggerNonUserCode]
			get
			{
				return _m_Data;
			}
			[System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.Synchronized), System.Diagnostics.DebuggerNonUserCode]
			set
			{
				if (_m_Data != null)
				{
					_m_Data.RowChanged -= m_Data_RowChanged;
				}

				_m_Data = value;

				if (value != null)
				{
					_m_Data.RowChanged += m_Data_RowChanged;
				}
			}
		}
		private string m_Error;
		private bool m_IsRead;

		public void Init(int _ID)
		{
			m_ObjID = _ID;
		}

		private void frmProdaja_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			string gr = null;
			//m_Data = Podaci.VratiKnjizareZaMagacin(0, gr)
			m_Magacini = SrednjiSloj.Pravila.VratiKnjizareZaMagacin(0, ref gr);
			m_IsRead = true;
			cboObj.DisplayMember = "naziv";
			cboObj.ValueMember = "objid";
			cboObj.DataSource = m_Magacini;
			cboObj.Visible = true;
			this.Text = "Prodaja knjiga";
			m_IsRead = false;
			if (m_ObjID > 0)
			{
				cboObj.SelectedValue = m_ObjID;
				cboObj_SelectedIndexChanged(cboObj, new EventArgs());
				cboObj.Visible = false;
				lblObj.Visible = false;
			}
		}

		private void cboObj_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (!m_IsRead)
			{
				m_Error = null;
				if (cboObj.SelectedIndex > -1)
				{
					m_ObjID = Convert.ToInt32(cboObj.SelectedValue.ToString());
					//Dim s As String = "select a.objid,a.bookid,a.ISBN,a.Naslov,a.Autor,k.Cena,a.Stanje from stanje(" + cboObj.SelectedValue.ToString + ") a inner join knjige k on a.bookid = k.bookid where stanje > 0"
					//m_Data = DB.GetData(s, m_Error)
					m_Data = SrednjiSloj.Pravila.VratiKnjigeZaProdaju(m_ObjID, ref m_Error);
					if (m_Error != null)
					{
						MessageBox.Show(m_Error);
					}
					else
					{
						if (!m_Data.Columns.Contains("Kom"))
						{
							m_Data.Columns.Add("Kom", typeof(int));
							m_Data.Columns.Add("Ukupno", typeof(decimal), "kom*cena");
						}
						foreach (DataRow r in m_Data.Rows)
						{
							r["Kom"] = 0;
						}
						FillGrid();
					}
				}
			}
		}

		private void FillGrid()
		{
			dgData.DataSource = m_Data;
			dgData.Columns[0].Visible = false;
			dgData.Columns[1].Visible = false;
			dgData.Columns[2].Visible = false;
			//dgData.Columns(6).Visible = False
			//dgData.Columns(3).HeaderText = "Naslov"
			//dgData.Columns(4).HeaderText = "Autor"
			//dgData.Columns(5).HeaderText = "Stanje"
			//dgData.Columns(6).HeaderText = "Cena"
			dgData.Columns[7].HeaderText = "Kom";
			dgData.Columns[8].HeaderText = "Ukupno";

			dgData.Columns[3].ReadOnly = true;
			dgData.Columns[4].ReadOnly = true;
			dgData.Columns[5].ReadOnly = true;
			dgData.Columns[6].ReadOnly = true;
			dgData.Columns[8].ReadOnly = true;
		}

		private void m_Data_RowChanged(object sender, System.Data.DataRowChangeEventArgs e)
		{
			if (!m_IsRead)
			{
				m_IsRead = true;
                if ((int)e.Row["kom"] > (int)e.Row["stanje"])
				{
					e.Row["kom"] = 0;
				}
				m_IsRead = false;
				double a = Convert.ToDouble(m_Data.Compute("SUM(Ukupno)", null));
				lblTotal.Text = string.Format("{0:N2}", a);
			}
		}

		private void Button1_Click(System.Object sender, System.EventArgs e)
		{
			m_Error = null;
			int docid = 0;
			int br = 0;
			string ozn = "";
			List<int> tot = new List<int>();

			tot.Add(8);

			if (MessageBox.Show("Može da se zaključi račun?", "PRODAJA", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
			{
				m_Data.DefaultView.RowFilter = "kom > 0";
				dgData.Columns[6].Visible = false;
				this.Invalidate();
				if (SrednjiSloj.Pravila.ObradaDokumenta(ref docid, 9, m_ObjID, 1, 0, 6, DateTime.Today, ref br, ref ozn, decimal.Parse(lblTotal.Text), "2", ref m_Error))
				{
					foreach (DataRow r in m_Data.Rows)
					{
						if (Convert.ToInt32(r["kom"]) > 0)
						{
							if (!SrednjiSloj.Pravila.EvidentirajPromet(docid, Convert.ToInt32(r["bookid"]), Convert.ToInt32(r["kom"]), ref m_Error))
							{
								MessageBox.Show(m_Error);
							}
						}
					}
					if (SrednjiSloj.Pravila.DodajStranu(docid, ref m_Error))
					{
						MessageBox.Show("Podaci su uspešno uneti.", "Račun " + ozn);
					}
					List<string> cap = new List<string>();
					m_Error = null;
					//Dim oi As DataTable = DB.GetData("SELECT * FROM Objekti where objid  =" + m_ObjID.ToString, m_Error)
					DataTable oi = SrednjiSloj.Pravila.VratiObjekatInfo(m_ObjID, ref m_Error);
					cap.Add(oi.Rows[0]["naziv"].ToString());
					cap.Add(oi.Rows[0]["adresa"].ToString());
					cap.Add(oi.Rows[0]["mesto"].ToString());
					cap.Add("Račun " + ozn);
					cap.Add("Datum: " + DateTime.Today.ToString("dd.MM.yyyy"));
					modMain.ExportToExcel(cap, dgData, "Račun", null, Application.StartupPath + "\\RN_" + ozn.Replace("\\", "-") + ".xlsx", 0, 0, tot, "kom > 0");
					System.Threading.Thread.Sleep(1000);
					this.Close();
				}
				else
				{
					MessageBox.Show(m_Error);
				}

			}
		}

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
			if (!(m_Data == null))
			{
				string f = "Naslov like '%" + txtSearch.Text + "%'";
				m_Data.DefaultView.RowFilter = f;
			}
        }

        private void dgData_DoubleClick(object sender, EventArgs e)
        {
			frmInput f = new frmInput();
			f.Init("PRODAJA", "Unesite broj knjiga koje kupac želi da kupi:");
			f.ShowDialog();
			if (f.DialogResult == DialogResult.OK)
			{
				if ((int)dgData.CurrentRow.Cells["stanje"].Value < Convert.ToInt32(f.Result))
				{
					MessageBox.Show("Ne možete prodati " + Convert.ToInt32(f.Result) + " knjiga, ako je na stanju " + dgData.CurrentRow.Cells["stanje"].Value.ToString() + " knjiga.","UNETO VIŠE NEGO ŠTO JE NA STANJU");
				}
				else
				{ 
					dgData.CurrentRow.Cells[7].Value = Convert.ToInt32(f.Result);
				}
            }
			f.Close();
			f.Dispose();
			f = null;
			txtSearch.Text = "";
			txtSearch.Focus();
			double a = Convert.ToDouble(m_Data.Compute("SUM(Ukupno)", null));
			lblTotal.Text = string.Format("{0:N2}", a);
		}
    }
}