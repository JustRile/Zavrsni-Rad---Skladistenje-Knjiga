﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmKnjiga
	{
		public frmKnjiga()
		{
			InitializeComponent();
		}

		private int m_BookID;
		public void Init(int _BookID)
		{
			m_BookID = _BookID;
		}

		private void frmKnjiga_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			if (m_BookID > 0)
			{
				string gr = null;
				DataTable t = SrednjiSloj.Pravila.VratiPodatkeOKnjizi(m_BookID, ref gr);
				if (gr == null)
				{
					if (t.Rows.Count > 0)
					{
						txtISBN.Text = t.Rows[0]["ISBN"].ToString();
						txtNaslov.Text = t.Rows[0]["Naslov"].ToString();
						txtAutor.Text = t.Rows[0]["Autor"].ToString();
						txtGodina.Text = t.Rows[0]["Godina"].ToString();
						txtCena.Text = Microsoft.VisualBasic.Strings.FormatNumber(t.Rows[0]["Cena"].ToString().Replace(".", ","), 2);
					}
				}
				else
				{
					MessageBox.Show(gr, "Izbor knjige");
				}
			}
		}

		private void Button1_Click(System.Object sender, System.EventArgs e)
		{
			string gr = null;
			if (SrednjiSloj.Pravila.AzurirajPodatkeOKnjizi(ref m_BookID, txtISBN.Text, txtNaslov.Text, txtAutor.Text, Convert.ToInt32(txtGodina.Text), Convert.ToDecimal(txtCena.Text), ref gr))
			{
				this.Close();
			}
			else
			{
				MessageBox.Show(gr, "EVIDENCIJA KNJIGA");
			}
		}
	}
}