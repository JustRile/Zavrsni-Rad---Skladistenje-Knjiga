﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;
using SpreadsheetLight;
using DocumentFormat.OpenXml.Spreadsheet;

namespace Knjizara
{
	internal static class modMain
	{

		public static void ExportToExcel(List<string> _Captions, DataGridView _DG, string _SheetName, string[,] _Comments, string _FileName, int _Vertical, double _ColWidth)
		{
			if (System.IO.File.Exists(_FileName))
			{
				System.IO.File.Delete(_FileName);
			}
			DataTable tbl = (DataTable)_DG.DataSource;
			string ss = "";
			for (int i = 0; i < tbl.Columns.Count; i++)
			{
				if (tbl.Columns[i].DataType == typeof(Int32))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(double))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(decimal))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(Int64))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(Int16))
				{
					ss += "0";
				}
				else
				{
					ss += "C";
				}
			}
			SpreadsheetLight.SLStyle stInt = new SpreadsheetLight.SLStyle();
			stInt.FormatCode = "#,##0";
			stInt.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDec = new SLStyle();
			stDec.FormatCode = "#,##0.00";
			stDec.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDate = new SLStyle();
			stDate.FormatCode = "dd.MM.yyyy";

			SLStyle stDefault = new SLStyle();
			stDefault.FormatCode = "@";

			SLStyle stHead = new SLStyle();
            stHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stHead.SetFontBold(true);
			stHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);

			SLStyle stVertHead = new SLStyle();
            stVertHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stVertHead.SetFontBold(true);
			stVertHead.Alignment.TextRotation = 90;
			stVertHead.Alignment.ShrinkToFit = true;
			stVertHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stVertHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stVertHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);
			//Dim f As New System.IO.StreamWriter(_FileName, False, System.Text.UnicodeEncoding.Default)
			Int64 brRedova = tbl.Rows.Count;
			//Write _Captions
			int red = 1;
			int kolona = 1;
			SLDocument excel = new SLDocument();
			excel.RenameWorksheet("Sheet1", _SheetName);
			int brstrana = 1;
			Int64 poStrani = 1000000;
			if (_Captions.Count + 2 + brRedova > poStrani)
			{
				Int64 pg = poStrani;
				Int64 ostalo = _Captions.Count + 2 + brRedova - poStrani;

				while (ostalo > 0)
				{
					brstrana += 1;
					ostalo = ostalo - poStrani - 1;
				}
			}

			Int64 poslred = 1;
			int pocinje = 1;
			for (int i = 0; i < _Captions.Count; i++)
			{
				excel.SetCellValue(i + 1, kolona, _Captions[i]);
				pocinje += 1;
			}
			pocinje += 1;


			int brkolona = _DG.Columns.Count;
			int mini = -1;
			for (int i = 1; i <= brstrana; i++)
			{
				//header
				if (i > 1)
				{
					excel.AddWorksheet("Strana " + i.ToString());
					pocinje = 1;
					poslred += poStrani - 1;
					excel.SelectWorksheet("Strana " + i.ToString());
				}
				kolona = 0;
				for (int kol = 0; kol < brkolona; kol++)
				{
					if (_DG.Columns[kol].Visible)
					{
						kolona += 1;
						if (_Vertical == 0)
						{
							excel.SetCellStyle(pocinje, kolona, stHead);
						}
						else if (kol < _Vertical)
						{
							excel.SetCellStyle(pocinje, kolona, stHead);
						}
						else
						{
							excel.SetCellStyle(pocinje, kolona, stVertHead);
						}
						excel.SetCellValue(pocinje, kolona, _DG.Columns[kol].HeaderText);
					}
					else
					{
						ConversionHelper.MidStatement(ref ss, kol + 1, "X", 1);
					}
				}
				//excel.AutoFitRow(pocinje)
				if (_Vertical > 0)
				{
					for (int ii = _Vertical; ii <= brkolona; ii++)
					{
						excel.SetColumnWidth(ii, _ColWidth);
					}
				}
				pocinje += 1;
				//podaci
				kolona = 0;
				poslred = 0;
				mini = (int)Math.Min(poStrani - 1, brRedova);
				for (int col = 0; col < ss.Length; col++)
				{
					SLStyle actStyle = stDefault;
					if (ss.Substring(col, 1) != "X")
					{
						kolona += 1;
						if (ss.Substring(col, 1) == "0")
						{
							actStyle = stInt;
						}
						else if (ss.Substring(col, 1) == "2")
						{
							actStyle = stDec;
						}
						else if (ss.Substring(col, 1) == "D")
						{
							actStyle = stDate;
						}
						for (int redic = 0; redic < mini; redic++)
						{
							excel.SetCellStyle(pocinje + redic, kolona, actStyle);
							excel.SetCellValue(pocinje + redic, kolona, tbl.Rows[(int)poslred + redic][col].ToString());
						}
					}

				}
				excel.FreezePanes(pocinje - 1, _Vertical);

			}
			pocinje += mini + 1;
			if (_Comments != null)
			{
				int exRed = _Comments.GetUpperBound(0);
				int exKol = _Comments.GetUpperBound(1);
				for (int i = 0; i <= exRed; i++)
				{
					for (int j = 0; j <= exKol; j++)
					{
						if (!(_Comments[i, j] == null))
						{
							string vv = _Comments[i, j];
							string fc = "@";
							SLStyle stStyle = new SLStyle();

							switch (vv.Substring(0, 1))
							{
								case "C":
									stStyle.FormatCode = fc;
									break;
								case "I":
								case "0":
									fc = "#,##0";
									stStyle.FormatCode = fc;
									stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);
									break;
								case "1":
								case "2":
								case "3":
								case "4":
								case "5":
								case "6":
									fc = "".PadLeft(Convert.ToInt32(vv.Substring(0, 1)), '0');
									stStyle.FormatCode = fc;
									stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

									break;
								case "D":
									stStyle.FormatCode = "dd.MM.yyyy";

									break;
								case "T":
									stStyle.FormatCode = "HH:mm:ss";

									break;
								default:
									stStyle.FormatCode = fc;

									break;
							}
							excel.SetCellStyle(pocinje + i, j + 1, stStyle);
							excel.SetCellValue(pocinje + i, j + 1, vv.Substring(1));
						}
					}
				}
			}

			lock (excel)
			{
				excel.SaveAs(_FileName);
			}
			//ReleaseComObject(excel)
			excel.Dispose();
			excel = null;
			Process.Start(_FileName);
		}

		public static void ExportToExcel(List<string> _Captions, DataGridView _DG, string _SheetName, string[,] _Comments, string _FileName, int _Vertical, double _ColWidth, List<int> _TotalForCols, string _Uslov = null)
		{
			if (System.IO.File.Exists(_FileName))
			{
				System.IO.File.Delete(_FileName);
			}
			DataTable tbla = (DataTable)_DG.DataSource;
			DataTable tbl = new DataTable();
			tbl = (DataTable)tbla.Clone();
			if (_Uslov != null)
			{
				tbla.DefaultView.RowFilter = _Uslov;
				tbl.Merge(tbla.DefaultView.ToTable());
			}
			else
			{
				tbl.Merge(tbla);
			}
			string ss = "";
			for (int i = 0; i < tbl.Columns.Count; i++)
			{
				if (tbl.Columns[i].DataType == typeof(Int32))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(double))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(decimal))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(Int64))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(Int16))
				{
					ss += "0";
				}
				else
				{
					ss += "C";
				}
			}
			SpreadsheetLight.SLStyle stInt = new SpreadsheetLight.SLStyle();
			stInt.FormatCode = "#,##0";
			stInt.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDec = new SLStyle();
			stDec.FormatCode = "#,##0.00";
			stDec.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDate = new SLStyle();
			stDate.FormatCode = "dd.MM.yyyy";

			SLStyle stDefault = new SLStyle();
			stDefault.FormatCode = "@";

			SLStyle stHead = new SLStyle();
            stHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stHead.SetFontBold(true);
			stHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);

			SLStyle stVertHead = new SLStyle();
            stVertHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stVertHead.SetFontBold(true);
			stVertHead.Alignment.TextRotation = 90;
			stVertHead.Alignment.ShrinkToFit = true;
			stVertHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stVertHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stVertHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);
			//Dim f As New System.IO.StreamWriter(_FileName, False, System.Text.UnicodeEncoding.Default)
			Int64 brRedova = tbl.Rows.Count;
			//Write _Captions
			int red = 1;
			int kolona = 1;
			SLDocument excel = new SLDocument();
			excel.RenameWorksheet("Sheet1", _SheetName);
			int brstrana = 1;
			Int64 poStrani = 1000000;
			if (_Captions.Count + 2 + brRedova > poStrani)
			{
				Int64 pg = poStrani;
				Int64 ostalo = _Captions.Count + 2 + brRedova - poStrani;

				while (ostalo > 0)
				{
					brstrana += 1;
					ostalo = ostalo - poStrani - 1;
				}
			}

			Int64 poslred = 1;
			int pocinje = 1;
			for (int i = 0; i < _Captions.Count; i++)
			{
				excel.SetCellValue(i + 1, kolona, _Captions[i]);
				pocinje += 1;
			}
			pocinje += 1;

			Dictionary<int, int> vidise = new Dictionary<int, int>();

			int brkolona = _DG.Columns.Count;
			int mini = -1;
			for (int i = 1; i <= brstrana; i++)
			{
				//header
				if (i > 1)
				{
					excel.AddWorksheet("Strana " + i.ToString());
					pocinje = 1;
					poslred += poStrani - 1;
					excel.SelectWorksheet("Strana " + i.ToString());
				}
				kolona = 0;
				int rbvid = 0;

				for (int kol = 0; kol < brkolona; kol++)
				{
					if (_DG.Columns[kol].Visible)
					{
						rbvid += 1;
						vidise.Add(kol, rbvid);

						kolona += 1;
						if (_Vertical == 0)
						{
							excel.SetCellStyle(pocinje, kolona, stHead);
						}
						else if (kol < _Vertical)
						{
							excel.SetCellStyle(pocinje, kolona, stHead);
						}
						else
						{
							excel.SetCellStyle(pocinje, kolona, stVertHead);
						}
						excel.SetCellValue(pocinje, kolona, _DG.Columns[kol].HeaderText);
					}
					else
					{
						ConversionHelper.MidStatement(ref ss, kol + 1, "X", 1);
					}
				}
				//excel.AutoFitRow(pocinje)
				if (_Vertical > 0)
				{
					for (int ii = _Vertical; ii <= brkolona; ii++)
					{
						excel.SetColumnWidth(ii, _ColWidth);
					}
				}
				pocinje += 1;
				//podaci
				kolona = 0;
				poslred = 0;
				mini = (int)Math.Min(poStrani - 1, brRedova);
				for (int col = 0; col < ss.Length; col++)
				{
					SLStyle actStyle = stDefault;
					if (ss.Substring(col, 1) != "X")
					{
						kolona += 1;
						if (ss.Substring(col, 1) == "0")
						{
							actStyle = stInt;
						}
						else if (ss.Substring(col, 1) == "2")
						{
							actStyle = stDec;
						}
						else if (ss.Substring(col, 1) == "D")
						{
							actStyle = stDate;
						}
						for (int redic = 0; redic < mini; redic++)
						{
							excel.SetCellStyle(pocinje + redic, kolona, actStyle);
							excel.SetCellValue(pocinje + redic, kolona, tbl.Rows[(int)poslred + redic][col].ToString());
						}
					}

				}
				excel.FreezePanes(pocinje - 1, _Vertical);

			}
			pocinje += mini + 1;
			if (_Comments != null)
			{
				int exRed = _Comments.GetUpperBound(0);
				int exKol = _Comments.GetUpperBound(1);
				for (int i = 0; i <= exRed; i++)
				{
					for (int j = 0; j <= exKol; j++)
					{
						if (!(_Comments[i, j] == null))
						{
							string vv = _Comments[i, j];
							string fc = "@";
							SLStyle stStyle = new SLStyle();

							switch (vv.Substring(0, 1))
							{
								case "C":
									stStyle.FormatCode = fc;
									break;
								case "I":
								case "0":
									fc = "#,##0";
									stStyle.FormatCode = fc;
									stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);
									break;
								case "1":
								case "2":
								case "3":
								case "4":
								case "5":
								case "6":
									fc = "".PadLeft(Convert.ToInt32(vv.Substring(0, 1)), '0');
									stStyle.FormatCode = fc;
									stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

									break;
								case "D":
									stStyle.FormatCode = "dd.MM.yyyy";

									break;
								case "T":
									stStyle.FormatCode = "HH:mm:ss";

									break;
								default:
									stStyle.FormatCode = fc;

									break;
							}
							excel.SetCellStyle(pocinje + i, j + 1, stStyle);
							excel.SetCellValue(pocinje + i, j + 1, vv.Substring(1));
						}
					}
				}
			}
			pocinje = _Captions.Count + 2 + tbl.Rows.Count + 1;
			kolona = 1;
			if (_TotalForCols != null)
			{

				excel.SetCellValue(pocinje, kolona, "TOTAL");
				SLStyle decStyle = new SLStyle();
				decStyle.FormatCode = "#,##0.00";
				decStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);
				decStyle.Font.Bold = true;

				for (int i = 0; i < _TotalForCols.Count; i++)
				{
					decimal a = Convert.ToDecimal(tbl.Compute("SUM(" + tbl.Columns[_TotalForCols[i]].ColumnName + ")", null));
					int b = vidise[_TotalForCols[i]] - 1;
					excel.SetCellStyle(pocinje, kolona + b, decStyle);
					excel.SetCellValue(pocinje, kolona + b, a);
				}
			}
			lock (excel)
			{
				excel.SaveAs(_FileName);
			}
			//ReleaseComObject(excel)
			excel.Dispose();
			excel = null;
			Process.Start(_FileName);
		}
		public struct Objekat
		{
			public string Naziv;
			public string Adresa;
			public string Mesto;
		}

		public static void BookDoc(Objekat _Iz, Objekat _U, string _Dokument, string _Oznaka, string _Opis, DateTime _Datum, decimal _Iznos, DataTable tbl, string _SheetName, string _FileName)
		{
			if (System.IO.File.Exists(_FileName))
			{
				System.IO.File.Delete(_FileName);
			}
			//Dim tbl As DataTable = DirectCast(_DG.DataSource, DataTable)
			string ss = "";
			for (int i = 0; i < tbl.Columns.Count; i++)
			{
				if (tbl.Columns[i].DataType == typeof(Int32))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(double))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(decimal))
				{
					ss += "2";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(DateTime))
				{
					ss += "D";
				}
				else if (tbl.Columns[i].DataType == typeof(Int64))
				{
					ss += "0";
				}
				else if (tbl.Columns[i].DataType == typeof(Int16))
				{
					ss += "0";
				}
				else
				{
					ss += "C";
				}
			}
			SpreadsheetLight.SLStyle stInt = new SpreadsheetLight.SLStyle();
			stInt.FormatCode = "#,##0";
			stInt.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDec = new SLStyle();
			stDec.FormatCode = "#,##0.00";
			stDec.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right);

			SLStyle stDate = new SLStyle();
			stDate.FormatCode = "dd.MM.yyyy";

			SLStyle stDefault = new SLStyle();
			stDefault.FormatCode = "@";

			SLStyle stHead = new SLStyle();
            stHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stHead.SetFontBold(true);
			stHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);

			SLStyle stVertHead = new SLStyle();
            stVertHead.SetPatternFill(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, System.Drawing.Color.LemonChiffon, System.Drawing.Color.Maroon);
			stVertHead.SetFontBold(true);
			stVertHead.Alignment.TextRotation = 90;
			stVertHead.Alignment.ShrinkToFit = true;
			stVertHead.SetHorizontalAlignment(HorizontalAlignmentValues.Center);
			stVertHead.SetVerticalAlignment(DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center);
            stVertHead.SetBottomBorder(DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Double, System.Drawing.Color.Black);
			//Dim f As New System.IO.StreamWriter(_FileName, False, System.Text.UnicodeEncoding.Default)
			Int64 brRedova = tbl.Rows.Count;
			//Write _Captions
			int red = 1;
			int kolona = 1;
			System.IO.File.Copy(Application.StartupPath + "\\BookDoc.xlsx", _FileName);
			SLDocument excel = new SLDocument(_FileName, "Sheet1");

			excel.RenameWorksheet("Sheet1", _SheetName);
			int brstrana = 1;
			Int64 poStrani = 1000000;
			if (_Iz.Naziv != null)
			{
				excel.SetCellValue(2, 2, _Iz.Naziv);
				excel.SetCellValue(3, 2, _Iz.Adresa);
				excel.SetCellValue(4, 2, _Iz.Mesto);
			}
			if (_U.Naziv != null)
			{
				excel.SetCellValue(2, 6, _U.Naziv);
				excel.SetCellValue(3, 6, _U.Adresa);
				excel.SetCellValue(4, 6, _U.Mesto);
			}
			//If _Captions.Count + 2 + brRedova > poStrani Then
			//    Dim pg As Int64 = poStrani
			//    Dim ostalo As Int64 = _Captions.Count + 2 + brRedova - poStrani

			//    While ostalo > 0
			//        brstrana += 1
			//        ostalo = ostalo - poStrani - 1
			//    End While
			//End If
			string s = _Dokument + " " + _Oznaka;
			excel.SetCellValue(5, 4, s);
			excel.SetCellValue(5, 8, _Datum);
			excel.SetCellValue(6, 3, _Opis);
			excel.SetCellValue(8, 8, _Iznos);

			Int64 poslred = 1;
			int pocinje = 1;
			//For i As Integer = 0 To _Captions.Count - 1
			//    excel.SetCellValue(i + 1, kolona, _Captions(i))
			//    pocinje += 1
			//Next
			//pocinje += 1


			int brkolona = tbl.Columns.Count;
			int mini = -1;
			for (int i = 1; i <= brstrana; i++)
			{
				//header
				if (i > 1)
				{
					excel.AddWorksheet("Strana " + i.ToString());
					pocinje = 1;
					poslred += poStrani - 1;
					excel.SelectWorksheet("Strana " + i.ToString());
				}
				kolona = 0;
				for (int kol = 0; kol < brkolona; kol++)
				{
					if (tbl.Columns[kol].Caption.Length > 0)
					{
						kolona += 1;
						//If _Vertical = 0 Then
						//    excel.SetCellStyle(pocinje, kolona, stHead)
						//ElseIf kol < _Vertical Then
						//    excel.SetCellStyle(pocinje, kolona, stHead)
						//Else
						//    excel.SetCellStyle(pocinje, kolona, stVertHead)
						//End If
						//excel.SetCellValue(pocinje, kolona, tbl.Columns(kol).ColumnName)
					}
					else
					{
						ConversionHelper.MidStatement(ref ss, kol + 1, "X", 1);
					}
				}
				//excel.AutoFitRow(pocinje)
				//If _Vertical > 0 Then
				//    For ii As Integer = _Vertical To brkolona
				//        excel.SetColumnWidth(ii, _ColWidth)
				//    Next
				//End If
				pocinje += 1;
				//podaci
				kolona = 1;
				poslred = 0;
				pocinje = 10;

				mini = (int)Math.Min(poStrani - 1, brRedova);
				for (int col = 0; col < ss.Length; col++)
				{
					SLStyle actStyle = stDefault;
					if (ss.Substring(col, 1) != "X")
					{
						kolona += 1;
						if (ss.Substring(col, 1) == "0")
						{
							actStyle = stInt;
						}
						else if (ss.Substring(col, 1) == "2")
						{
							actStyle = stDec;
						}
						else if (ss.Substring(col, 1) == "D")
						{
							actStyle = stDate;
						}
						for (int redic = 0; redic < mini; redic++)
						{
							excel.SetCellStyle(pocinje + redic, kolona, actStyle);
							excel.SetCellValue(pocinje + redic, kolona, tbl.Rows[(int)poslred + redic][col].ToString ());
						}
					}

				}
				//excel.FreezePanes(pocinje - 1, _Vertical)

			}

			pocinje += mini + 1;
			//If Not _Comments Is Nothing Then
			//    Dim exRed As Integer = _Comments.GetUpperBound(0)
			//    Dim exKol As Integer = _Comments.GetUpperBound(1)
			//    For i As Integer = 0 To exRed
			//        For j As Integer = 0 To exKol
			//            If Not _Comments(i, j) Is Nothing Then
			//                Dim vv As String = _Comments(i, j)
			//                Dim fc As String = "@"
			//                Dim stStyle As New SLStyle

			//                Select Case vv.Substring(0, 1)
			//                    Case "C"
			//                        stStyle.FormatCode = fc
			//                    Case "I", "0"
			//                        fc = "#,##0"
			//                        stStyle.FormatCode = fc
			//                        stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right)
			//                    Case "1", "2", "3", "4", "5", "6"
			//                        fc = "".PadLeft(Convert.ToInt32(vv.Substring(0, 1)), "0")
			//                        stStyle.FormatCode = fc
			//                        stStyle.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Right)

			//                    Case "D"
			//                        stStyle.FormatCode = "dd.MM.yyyy"

			//                    Case "T"
			//                        stStyle.FormatCode = "HH:mm:ss"

			//                    Case Else
			//                        stStyle.FormatCode = fc

			//                End Select
			//                excel.SetCellStyle(pocinje + i, j + 1, stStyle)
			//                excel.SetCellValue(pocinje + i, j + 1, vv.Substring(1))
			//            End If
			//        Next
			//    Next
			//End If

			lock (excel)
			{
				excel.SaveAs(_FileName);
			}
			//ReleaseComObject(excel)
			excel.Dispose();
			excel = null;
			Process.Start(_FileName);
		}

		public static void ReleaseComObject(ref object Reference)
		{
			try
			{
				while (!(System.Runtime.InteropServices.Marshal.ReleaseComObject(Reference) <= 0))
				{
				}
				GC.Collect();
				GC.WaitForPendingFinalizers();
			}
			catch
			{
			}
			finally
			{
				Reference = null;
			}
		}
	}

}