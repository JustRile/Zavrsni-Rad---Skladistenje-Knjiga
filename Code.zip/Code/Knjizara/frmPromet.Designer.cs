﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmPromet : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPromet));
			this.Label1 = new System.Windows.Forms.Label();
			this.cboRM = new System.Windows.Forms.ComboBox();
			this.dgStanje = new System.Windows.Forms.DataGridView();
			this.ContextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.mnuUExcel = new System.Windows.Forms.ToolStripMenuItem();
			this.cboObj = new System.Windows.Forms.ComboBox();
			this.lblObj = new System.Windows.Forms.Label();
			this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
			this.mnuSearch = new System.Windows.Forms.ToolStripButton();
			this.mnuTreb = new System.Windows.Forms.ToolStripButton();
			this.mnuPri = new System.Windows.Forms.ToolStripButton();
			this.mnuOtp = new System.Windows.Forms.ToolStripButton();
			this.mnuKomisija = new System.Windows.Forms.ToolStripButton();
			this.mnuReklamacija = new System.Windows.Forms.ToolStripButton();
			this.mnuDost = new System.Windows.Forms.ToolStripButton();
			this.mnuUKnjizaru = new System.Windows.Forms.ToolStripButton();
			this.lblOpcija = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)this.dgStanje).BeginInit();
			this.ContextMenuStrip1.SuspendLayout();
			this.ToolStrip1.SuspendLayout();
			this.SuspendLayout();
			//
			//Label1
			//
			this.Label1.AutoSize = true;
			this.Label1.Location = new System.Drawing.Point(15, 52);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(76, 13);
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Vrsta korisnika";
			//
			//cboRM
			//
			this.cboRM.FormattingEnabled = true;
			this.cboRM.Location = new System.Drawing.Point(97, 44);
			this.cboRM.Name = "cboRM";
			this.cboRM.Size = new System.Drawing.Size(195, 21);
			this.cboRM.TabIndex = 1;
			//
			//dgStanje
			//
			this.dgStanje.AllowUserToAddRows = false;
			this.dgStanje.AllowUserToDeleteRows = false;
			this.dgStanje.Anchor = (System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right);
			this.dgStanje.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.dgStanje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgStanje.ContextMenuStrip = this.ContextMenuStrip1;
			this.dgStanje.Location = new System.Drawing.Point(15, 98);
			this.dgStanje.Name = "dgStanje";
			this.dgStanje.ReadOnly = true;
			this.dgStanje.Size = new System.Drawing.Size(669, 237);
			this.dgStanje.TabIndex = 4;
			//
			//ContextMenuStrip1
			//
			this.ContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.mnuUExcel});
			this.ContextMenuStrip1.Name = "ContextMenuStrip1";
			this.ContextMenuStrip1.Size = new System.Drawing.Size(153, 26);
			//
			//mnuUExcel
			//
			this.mnuUExcel.Image = (System.Drawing.Image)resources.GetObject("mnuUExcel.Image");
			this.mnuUExcel.Name = "mnuUExcel";
			this.mnuUExcel.Size = new System.Drawing.Size(152, 22);
			this.mnuUExcel.Text = "Prebaci u Excel";
			//
			//cboObj
			//
			this.cboObj.FormattingEnabled = true;
			this.cboObj.Location = new System.Drawing.Point(97, 71);
			this.cboObj.Name = "cboObj";
			this.cboObj.Size = new System.Drawing.Size(195, 21);
			this.cboObj.TabIndex = 12;
			this.cboObj.Visible = false;
			//
			//lblObj
			//
			this.lblObj.AutoSize = true;
			this.lblObj.Location = new System.Drawing.Point(15, 79);
			this.lblObj.Name = "lblObj";
			this.lblObj.Size = new System.Drawing.Size(44, 13);
			this.lblObj.TabIndex = 11;
			this.lblObj.Text = "Objekat";
			this.lblObj.Visible = false;
			//
			//ToolStrip1
			//
			this.ToolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.mnuSearch, this.mnuTreb, this.mnuPri, this.mnuOtp, this.mnuKomisija, this.mnuReklamacija, this.mnuDost, this.mnuUKnjizaru});
			this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
			this.ToolStrip1.Name = "ToolStrip1";
			this.ToolStrip1.Size = new System.Drawing.Size(696, 39);
			this.ToolStrip1.TabIndex = 13;
			this.ToolStrip1.Text = "ToolStrip1";
			//
			//mnuSearch
			//
			this.mnuSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuSearch.Image = (System.Drawing.Image)resources.GetObject("mnuSearch.Image");
			this.mnuSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuSearch.Name = "mnuSearch";
			this.mnuSearch.Size = new System.Drawing.Size(36, 36);
			this.mnuSearch.Text = "Za prijem";
			//
			//mnuTreb
			//
			this.mnuTreb.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuTreb.Image = (System.Drawing.Image)resources.GetObject("mnuTreb.Image");
			this.mnuTreb.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuTreb.Name = "mnuTreb";
			this.mnuTreb.Size = new System.Drawing.Size(36, 36);
			this.mnuTreb.Text = "Trebovanje";
			//
			//mnuPri
			//
			this.mnuPri.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuPri.Image = (System.Drawing.Image)resources.GetObject("mnuPri.Image");
			this.mnuPri.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuPri.Name = "mnuPri";
			this.mnuPri.Size = new System.Drawing.Size(36, 36);
			this.mnuPri.Text = "Prijemnica";
			//
			//mnuOtp
			//
			this.mnuOtp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuOtp.Image = (System.Drawing.Image)resources.GetObject("mnuOtp.Image");
			this.mnuOtp.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuOtp.Name = "mnuOtp";
			this.mnuOtp.Size = new System.Drawing.Size(36, 36);
			this.mnuOtp.Text = "Otpremnica";
			//
			//mnuKomisija
			//
			this.mnuKomisija.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuKomisija.Image = (System.Drawing.Image)resources.GetObject("mnuKomisija.Image");
			this.mnuKomisija.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuKomisija.Name = "mnuKomisija";
			this.mnuKomisija.Size = new System.Drawing.Size(36, 36);
			this.mnuKomisija.Text = "Konisija";
			//
			//mnuReklamacija
			//
			this.mnuReklamacija.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuReklamacija.Image = (System.Drawing.Image)resources.GetObject("mnuReklamacija.Image");
			this.mnuReklamacija.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuReklamacija.Name = "mnuReklamacija";
			this.mnuReklamacija.Size = new System.Drawing.Size(36, 36);
			this.mnuReklamacija.Text = "Reklamacija";
			//
			//mnuDost
			//
			this.mnuDost.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuDost.Image = (System.Drawing.Image)resources.GetObject("mnuDost.Image");
			this.mnuDost.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuDost.Name = "mnuDost";
			this.mnuDost.Size = new System.Drawing.Size(36, 36);
			this.mnuDost.Text = "Dostavnica";
			//
			//mnuUKnjizaru
			//
			this.mnuUKnjizaru.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.mnuUKnjizaru.Image = (System.Drawing.Image)resources.GetObject("mnuUKnjizaru.Image");
			this.mnuUKnjizaru.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.mnuUKnjizaru.Name = "mnuUKnjizaru";
			this.mnuUKnjizaru.Size = new System.Drawing.Size(36, 36);
			this.mnuUKnjizaru.Text = "Prijem u knjižaru";
			//
			//lblOpcija
			//
			this.lblOpcija.Anchor = (System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.lblOpcija.BackColor = System.Drawing.Color.Transparent;
			this.lblOpcija.Location = new System.Drawing.Point(481, 9);
			this.lblOpcija.Name = "lblOpcija";
			this.lblOpcija.Size = new System.Drawing.Size(203, 17);
			this.lblOpcija.TabIndex = 14;
			this.lblOpcija.Text = "Stanje";
			this.lblOpcija.TextAlign = System.Drawing.ContentAlignment.TopRight;
			//
			//frmPromet
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(696, 339);
			this.Controls.Add(this.lblOpcija);
			this.Controls.Add(this.ToolStrip1);
			this.Controls.Add(this.cboObj);
			this.Controls.Add(this.lblObj);
			this.Controls.Add(this.dgStanje);
			this.Controls.Add(this.cboRM);
			this.Controls.Add(this.Label1);
			this.Name = "frmPromet";
			this.Text = "Promet";
			((System.ComponentModel.ISupportInitialize)this.dgStanje).EndInit();
			this.ContextMenuStrip1.ResumeLayout(false);
			this.ToolStrip1.ResumeLayout(false);
			this.ToolStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmPromet_Load);
			cboRM.SelectedIndexChanged += new System.EventHandler(cboRM_SelectedIndexChanged);
			cboObj.SelectedIndexChanged += new System.EventHandler(cboObj_SelectedIndexChanged);
			mnuTreb.Click += new System.EventHandler(mnuTreb_Click);
			mnuPri.Click += new System.EventHandler(mnuPri_Click);
			mnuOtp.Click += new System.EventHandler(mnuOtp_Click);
			mnuKomisija.Click += new System.EventHandler(mnuKomisija_Click);
			mnuUKnjizaru.Click += new System.EventHandler(mnuUKnjizaru_Click);
			mnuDost.Click += new System.EventHandler(mnuDost_Click);
			mnuReklamacija.Click += new System.EventHandler(mnuReklamacija_Click);
			mnuUExcel.Click += new System.EventHandler(mnuUExcel_Click);
		}
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.ComboBox cboRM;
		internal System.Windows.Forms.DataGridView dgStanje;
		internal System.Windows.Forms.ComboBox cboObj;
		internal System.Windows.Forms.Label lblObj;
		internal System.Windows.Forms.ToolStrip ToolStrip1;
		internal System.Windows.Forms.ToolStripButton mnuSearch;
		internal System.Windows.Forms.ToolStripButton mnuTreb;
		internal System.Windows.Forms.ToolStripButton mnuPri;
		internal System.Windows.Forms.ToolStripButton mnuOtp;
		internal System.Windows.Forms.ToolStripButton mnuKomisija;
		internal System.Windows.Forms.ToolStripButton mnuReklamacija;
		internal System.Windows.Forms.ToolStripButton mnuDost;
		internal System.Windows.Forms.ToolStripButton mnuUKnjizaru;
		internal System.Windows.Forms.Label lblOpcija;
		internal System.Windows.Forms.ContextMenuStrip ContextMenuStrip1;
		internal System.Windows.Forms.ToolStripMenuItem mnuUExcel;
	}

}