﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmZaposleni
	{
		public frmZaposleni()
		{
			InitializeComponent();
		}

		private bool m_IsPasswordChanged;
		private DataTable m_Data;
		private DataTable m_RM;

		private void frmZaposleni_Load(System.Object sender, System.EventArgs e)
		{
			try
			{
				string gr = null;
				//m_Data = DB.GetData("SELECT empid,vrsta,objid,ime,sifra,vazi FROM Zaposleni where vazi = '1' and sifra <> 'admin'", gr)
				m_Data = SrednjiSloj.Pravila.VratiAktivneZaposlene(ref gr);
				if (gr != null)
				{
					MessageBox.Show(gr);
					return;
				}
				m_Data.Columns.Add("aktivan", typeof(bool));
				foreach (DataRow r in m_Data.Rows)
				{
					r["aktivan"] = Convert.ToBoolean(true);
				}
				//m_RM = DB.GetData("SELECT * FROM VrstaRM", gr)
				m_RM = SrednjiSloj.Pravila.VratiSpisakVrstaRM(ref gr);
				if (gr != null)
				{
					MessageBox.Show(gr);
					return;
				}
				cboRM.DisplayMember = "naziv";
				cboRM.ValueMember = "vrsta";
				cboRM.DataSource = m_RM;
				dgData.AutoGenerateColumns = false;
				dgData.Columns[0].DataPropertyName = "empid";
				dgData.Columns[1].DataPropertyName = "vrsta";
				dgData.Columns[2].DataPropertyName = "objid";
				dgData.Columns[3].DataPropertyName = "ime";
				dgData.Columns[4].DataPropertyName = "sifra";
				dgData.Columns[5].DataPropertyName = "vazi";
				dgData.Columns[6].DataPropertyName = "aktivan";

				dgData.DataSource = m_Data;

				m_Data.AcceptChanges();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void cmdNew_Click(System.Object sender, System.EventArgs e)
		{
			DataRow r = m_Data.NewRow();
			r[0] = 0;
			r[1] = "";
			r[2] = "";
			r[3] = "";
			r[4] = 3;
			r[5] = 0;
			r[6] = "";
			r[7] = "";
			r[8] = "1";
			m_Data.Rows.Add(r);
			//dgData.Enabled = False
			//dgData.CurrentCell = dgData.Rows(dgData.Rows.Count - 1).Cells(1)

		}

		//Private Sub DisplayRow()
		//    txtIme.Text = dgData.CurrentRow.Cells(1).Value.ToString
		//    txtSifra.Text = dgData.CurrentRow.Cells(2).Value.ToString
		//    txtPWD.Text = dgData.CurrentRow.Cells(3).Value.ToString
		//    cboRM.SelectedValue = Convert.ToInt32(dgData.CurrentRow.Cells(4).Value.ToString)
		//    cboObj.SelectedValue = Convert.ToInt32(dgData.CurrentRow.Cells(5).Value.ToString)
		//End Sub

		private void cboRM_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (cboRM.SelectedIndex > -1)
			{
				lblObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
				cboObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
				if (Convert.ToInt32(cboRM.SelectedValue) > 2)
				{
					m_Data.DefaultView.RowFilter = "1 = 1";
					m_Data.DefaultView.RowFilter = "vrsta = " + cboRM.SelectedValue.ToString();
				}
				if (Convert.ToInt32(cboRM.SelectedValue) == 1)
				{
					lblObj.Text = "Knjižara";
					cboObj.ValueMember = "objid";
					cboObj.DisplayMember = "naziv";
					string gr = null;
					cboObj.DataSource = SrednjiSloj.Pravila.VratiKnjizareZaMagacin(0, ref gr);
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 2)
				{
					lblObj.Text = "Magacin";
					cboObj.ValueMember = "objid";
					cboObj.DisplayMember = "naziv";
					string gr = null;
					cboObj.DataSource = SrednjiSloj.Pravila.VratiSpisakMagacina(ref gr);

				}
			}
		}

		private void dgData_CellContentClick(System.Object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
		{

		}

		private void dgData_UserAddedRow(object sender, System.Windows.Forms.DataGridViewRowEventArgs e)
		{
			if (dgData.CurrentRow != null)
			{
				dgData.CurrentRow.Cells[0].Value = 0;
				dgData.CurrentRow.Cells[1].Value = cboRM.SelectedValue;
				if (cboObj.Visible)
				{
					dgData.CurrentRow.Cells[2].Value = cboObj.SelectedValue;
				}
				else
				{
					dgData.CurrentRow.Cells[2].Value = 0;
				}
				dgData.CurrentRow.Cells[4].Value = "Korisnik";
				dgData.CurrentRow.Cells[5].Value = "1";
				dgData.CurrentRow.Cells[6].Value = Convert.ToBoolean(true);
			}
		}

		private void Button1_Click(System.Object sender, System.EventArgs e)
		{
			foreach (DataRow r in m_Data.Rows)
			{
				if (r.RowState != DataRowState.Unchanged)
				{
					if (Convert.ToBoolean(r["aktivan"]))
					{
						r[5] = "1";
					}
					string m_Error = null;
					DataTable t = SrednjiSloj.Pravila.ObradaZaposlenog(Convert.ToInt32(r[0]), Convert.ToInt32(r[1]), Convert.ToInt32(r[2]), Convert.ToString(r[3]), Convert.ToString(r[4]), Convert.ToString(r[5]), ref m_Error);

				}
			}
			this.Close();
		}

		private void cboObj_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (cboObj.Visible)
			{
				m_Data.DefaultView.RowFilter = "1 = 1";
				m_Data.DefaultView.RowFilter = "objid = " + cboObj.SelectedValue.ToString();

			}
		}
	}
}