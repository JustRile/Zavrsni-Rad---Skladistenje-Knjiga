﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmChangePWD
	{

		public frmChangePWD()
		{
			InitializeComponent();
		}

		private void frmChangePWD_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
		}

		private void OK_Click(System.Object sender, System.EventArgs e)
		{
			this.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.Close();
		}
	}
}