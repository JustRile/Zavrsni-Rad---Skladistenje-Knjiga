﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmZaposleni : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmZaposleni));
			this.Label4 = new System.Windows.Forms.Label();
			this.cboRM = new System.Windows.Forms.ComboBox();
			this.lblObj = new System.Windows.Forms.Label();
			this.cboObj = new System.Windows.Forms.ComboBox();
			this.Button1 = new System.Windows.Forms.Button();
			this.dgData = new System.Windows.Forms.DataGridView();
			this.empid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.objid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.vrsta = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ime = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sifra = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.vazi = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.aktivan = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			((System.ComponentModel.ISupportInitialize)this.dgData).BeginInit();
			this.SuspendLayout();
			//
			//Label4
			//
			this.Label4.AutoSize = true;
			this.Label4.Location = new System.Drawing.Point(9, 2);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(75, 13);
			this.Label4.TabIndex = 7;
			this.Label4.Text = "Radi na mestu";
			this.Label4.Visible = false;
			//
			//cboRM
			//
			this.cboRM.FormattingEnabled = true;
			this.cboRM.Location = new System.Drawing.Point(12, 18);
			this.cboRM.Name = "cboRM";
			this.cboRM.Size = new System.Drawing.Size(195, 21);
			this.cboRM.TabIndex = 8;
			//
			//lblObj
			//
			this.lblObj.AutoSize = true;
			this.lblObj.Location = new System.Drawing.Point(16, 48);
			this.lblObj.Name = "lblObj";
			this.lblObj.Size = new System.Drawing.Size(44, 13);
			this.lblObj.TabIndex = 9;
			this.lblObj.Text = "Objekat";
			this.lblObj.Visible = false;
			//
			//cboObj
			//
			this.cboObj.FormattingEnabled = true;
			this.cboObj.Location = new System.Drawing.Point(12, 64);
			this.cboObj.Name = "cboObj";
			this.cboObj.Size = new System.Drawing.Size(195, 21);
			this.cboObj.TabIndex = 10;
			this.cboObj.Visible = false;
			//
			//Button1
			//
			this.Button1.Image = (System.Drawing.Image)resources.GetObject("Button1.Image");
			this.Button1.Location = new System.Drawing.Point(147, 279);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(75, 23);
			this.Button1.TabIndex = 12;
			this.Button1.UseVisualStyleBackColor = true;
			//
			//dgData
			//
			this.dgData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {this.empid, this.objid, this.vrsta, this.ime, this.sifra, this.vazi, this.aktivan});
			this.dgData.Location = new System.Drawing.Point(12, 91);
			this.dgData.Name = "dgData";
			this.dgData.Size = new System.Drawing.Size(341, 182);
			this.dgData.TabIndex = 13;
			//
			//empid
			//
			this.empid.HeaderText = "empid";
			this.empid.Name = "empid";
			this.empid.ReadOnly = true;
			this.empid.Visible = false;
			//
			//objid
			//
			this.objid.HeaderText = "objid";
			this.objid.Name = "objid";
			this.objid.Visible = false;
			//
			//vrsta
			//
			this.vrsta.HeaderText = "vrsta";
			this.vrsta.Name = "vrsta";
			this.vrsta.Visible = false;
			//
			//ime
			//
			this.ime.HeaderText = "Ime";
			this.ime.Name = "ime";
			//
			//sifra
			//
			this.sifra.HeaderText = "Šifra";
			this.sifra.Name = "sifra";
			//
			//vazi
			//
			this.vazi.HeaderText = "vazi";
			this.vazi.Name = "vazi";
			this.vazi.Visible = false;
			//
			//aktivan
			//
			this.aktivan.HeaderText = "Važi";
			this.aktivan.Name = "aktivan";
			this.aktivan.Width = 60;
			//
			//frmZaposleni
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(361, 304);
			this.Controls.Add(this.dgData);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.cboObj);
			this.Controls.Add(this.lblObj);
			this.Controls.Add(this.cboRM);
			this.Controls.Add(this.Label4);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmZaposleni";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Zaposleni";
			((System.ComponentModel.ISupportInitialize)this.dgData).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(frmZaposleni_Load);
			cboRM.SelectedIndexChanged += new System.EventHandler(cboRM_SelectedIndexChanged);
			dgData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgData_CellContentClick);
			dgData.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(dgData_UserAddedRow);
			Button1.Click += new System.EventHandler(Button1_Click);
			cboObj.SelectedIndexChanged += new System.EventHandler(cboObj_SelectedIndexChanged);
		}
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.ComboBox cboRM;
		internal System.Windows.Forms.Label lblObj;
		internal System.Windows.Forms.ComboBox cboObj;
		internal System.Windows.Forms.Button Button1;
		internal System.Windows.Forms.DataGridView dgData;
		internal System.Windows.Forms.DataGridViewTextBoxColumn empid;
		internal System.Windows.Forms.DataGridViewTextBoxColumn objid;
		internal System.Windows.Forms.DataGridViewTextBoxColumn vrsta;
		internal System.Windows.Forms.DataGridViewTextBoxColumn ime;
		internal System.Windows.Forms.DataGridViewTextBoxColumn sifra;
		internal System.Windows.Forms.DataGridViewTextBoxColumn vazi;
		internal System.Windows.Forms.DataGridViewCheckBoxColumn aktivan;
	}

}