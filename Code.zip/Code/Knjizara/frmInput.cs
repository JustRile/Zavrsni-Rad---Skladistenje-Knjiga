﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Knjizara
{
    public partial class frmInput : Form
    {
        private string m_Caption;
        private string m_Formcaption;
        private string m_Result;
        private bool m_mozeNula;

        public void Init(string _FormCaption, string _Caption)
        {
            m_Formcaption = _FormCaption;
            m_Caption = _Caption;
        }
                public void Init(string _FormCaption, string _Caption,bool _Moze)
        {
            m_Formcaption = _FormCaption;
            m_Caption = _Caption;
            m_mozeNula = _Moze;
        }
        public string Result { get { return m_Result; } }
        public frmInput()
        {
            InitializeComponent();
        }

        private void frmInput_Load(object sender, EventArgs e)
        {
            this.Text = m_Formcaption;
            lblText.Text = m_Caption;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (int.TryParse(txtInput.Text, out i))
            {
                if ((i >= 0) && (!(m_mozeNula )))
                {
                    m_Result = txtInput.Text;
                    this.DialogResult = DialogResult.OK;
                }
                else if (!(m_mozeNula ))
                {
                    MessageBox.Show("Uneti podatak mora biti pozitivan broj.", "NEISPRAVAN UNOS");
                    txtInput.Text = "";
                    txtInput.Focus();
                }
                else {
                    m_Result = txtInput.Text;
                    this.DialogResult = DialogResult.OK;
                }
            }
            else
            {
                MessageBox.Show("Uneti podatak mora biti pozitivan broj.", "NEISPRAVAN UNOS");
                txtInput.Text = "";
                txtInput.Focus();
            }
        }

        private void txtInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                button1_Click(button1, new EventArgs());
            }
        }
    }
}
