﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmLogin
	{

		// TODO: Insert code to perform custom authentication using the provided username and password 
		// (See http://go.microsoft.com/fwlink/?LinkId=35339).  
		// The custom principal can then be attached to the current thread's principal as follows: 
		//     My.User.CurrentPrincipal = CustomPrincipal
		// where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
		// Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
		// such as the username, display name, etc.

		public frmLogin()
		{
			InitializeComponent();
		}

		private bool isDefault = false;
		private string m_Error = null;

		private void OK_Click(System.Object sender, System.EventArgs e)
		{
			if (txtUser.Text == "admin" && txtPWD.Text == "Maestro")
			{
				SrednjiSloj.Pravila.EmpID = 1;
				this.DialogResult = System.Windows.Forms.DialogResult.OK;
				this.Close();
			}
			if (txtUser.Text.Trim().Length > 0 && txtPWD.Text.Length >= 8)
			{
				if (SrednjiSloj.Pravila.IsUserValid(txtUser.Text, txtPWD.Text, ref m_Error))
				{
					if (txtUser.Text == txtPWD.Text)
					{
						string pwd = "";
						frmChangePWD f = new frmChangePWD();
						f.ShowDialog();
						if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
						{
							pwd = f.txtPWD.Text;
						}
						f.Close();
						f.Dispose();
						f = null;
						if (pwd.Trim().Length > 0)
						{
							if (SrednjiSloj.Pravila.UpdatePWD(SrednjiSloj.Pravila.EmpID, pwd, ref m_Error))
							{
								this.DialogResult = System.Windows.Forms.DialogResult.OK;
								this.Close();
							}
						}
					}
					else
					{
						this.DialogResult = System.Windows.Forms.DialogResult.OK;
						this.Close();
					}
				}
			}
		}

		private void Cancel_Click(System.Object sender, System.EventArgs e)
		{
			System.Environment.Exit(1);
		}

		private void frmLogin_Load(System.Object sender, System.EventArgs e)
		{

		}
	}

}