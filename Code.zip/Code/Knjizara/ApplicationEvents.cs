﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	namespace My
	{

		// The following events are available for MyApplication:
		// 
		// Startup: Raised when the application starts, before the startup form is created.
		// Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
		// UnhandledException: Raised if the application encounters an unhandled exception.
		// StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
		// NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
		internal partial class MyApplication : Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase
		{

			protected override bool OnInitialize(System.Collections.ObjectModel.ReadOnlyCollection<string> commandLineArgs)
			{

				// Set the display time to 5000 milliseconds (5 seconds). 

				this.MinimumSplashScreenDisplayTime = 3000;
				string m_Error = null;
				while (!SrednjiSloj.Pravila.Konektujse (ref m_Error))
				{
					System.Threading.Thread.Sleep(100);
				}
				//Dim t As DataTable = DB.GetData("SELECT * FROM Objekti", m_Error)
				try
				{
					DataTable t = SrednjiSloj.Pravila.VratiSpisakVrstaRM(ref m_Error);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
				return base.OnInitialize(commandLineArgs);

			}
		}


	}


}