﻿using System.Xml;

//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class Form1 : System.Windows.Forms.Form
	{
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
			this.PostavkaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuMagacini = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuKnjizare = new System.Windows.Forms.ToolStripMenuItem();
			this.ZaposleniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuAktivnosti = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuPromet = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.PreglediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuProdaja = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuAktiv2 = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuPromet2 = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.mnuPregled2 = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuProdaja2 = new System.Windows.Forms.ToolStripMenuItem();
			this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
			this.lblRM = new System.Windows.Forms.ToolStripStatusLabel();
			this.lblRadnik = new System.Windows.Forms.ToolStripStatusLabel();
			this.lblObj = new System.Windows.Forms.ToolStripStatusLabel();
			this.mnuKnjige = new System.Windows.Forms.ToolStripMenuItem();
			this.MenuStrip1.SuspendLayout();
			this.StatusStrip1.SuspendLayout();
			this.SuspendLayout();
			//
			//MenuStrip1
			//
			this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.PostavkaToolStripMenuItem, this.mnuAktivnosti, this.mnuAktiv2});
			this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
			this.MenuStrip1.Name = "MenuStrip1";
			this.MenuStrip1.Size = new System.Drawing.Size(897, 24);
			this.MenuStrip1.TabIndex = 0;
			this.MenuStrip1.Text = "MenuStrip1";
			//
			//PostavkaToolStripMenuItem
			//
			this.PostavkaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {this.mnuMagacini, this.mnuKnjizare, this.ZaposleniToolStripMenuItem, this.mnuKnjige});
			this.PostavkaToolStripMenuItem.Name = "PostavkaToolStripMenuItem";
			this.PostavkaToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
			this.PostavkaToolStripMenuItem.Text = "Postavka";
			//
			//mnuMagacini
			//
			this.mnuMagacini.Name = "mnuMagacini";
			this.mnuMagacini.Size = new System.Drawing.Size(152, 22);
			this.mnuMagacini.Text = "Magacini";
			//
			//mnuKnjizare
			//
			this.mnuKnjizare.Name = "mnuKnjizare";
			this.mnuKnjizare.Size = new System.Drawing.Size(152, 22);
			this.mnuKnjizare.Text = "Knjižare";
			//
			//ZaposleniToolStripMenuItem
			//
			this.ZaposleniToolStripMenuItem.Name = "ZaposleniToolStripMenuItem";
			this.ZaposleniToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.ZaposleniToolStripMenuItem.Text = "Zaposleni";
			//
			//mnuAktivnosti
			//
			this.mnuAktivnosti.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {this.mnuPromet, this.ToolStripMenuItem1, this.PreglediToolStripMenuItem, this.mnuProdaja});
			this.mnuAktivnosti.Name = "mnuAktivnosti";
			this.mnuAktivnosti.Size = new System.Drawing.Size(72, 20);
			this.mnuAktivnosti.Text = "Aktivnosti";
			//
			//mnuPromet
			//
			this.mnuPromet.Name = "mnuPromet";
			this.mnuPromet.Size = new System.Drawing.Size(117, 22);
			this.mnuPromet.Text = "Promet";
			//
			//ToolStripMenuItem1
			//
			this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
			this.ToolStripMenuItem1.Size = new System.Drawing.Size(114, 6);
			//
			//PreglediToolStripMenuItem
			//
			this.PreglediToolStripMenuItem.Name = "PreglediToolStripMenuItem";
			this.PreglediToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
			this.PreglediToolStripMenuItem.Text = "Pregledi";
			//
			//mnuProdaja
			//
			this.mnuProdaja.Name = "mnuProdaja";
			this.mnuProdaja.Size = new System.Drawing.Size(117, 22);
			this.mnuProdaja.Text = "Prodaja";
			//
			//mnuAktiv2
			//
			this.mnuAktiv2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {this.mnuPromet2, this.ToolStripSeparator1, this.mnuPregled2, this.mnuProdaja2});
			this.mnuAktiv2.Name = "mnuAktiv2";
			this.mnuAktiv2.Size = new System.Drawing.Size(72, 20);
			this.mnuAktiv2.Text = "Aktivnosti";
			//
			//mnuPromet2
			//
			this.mnuPromet2.Name = "mnuPromet2";
			this.mnuPromet2.Size = new System.Drawing.Size(117, 22);
			this.mnuPromet2.Text = "Promet";
			//
			//ToolStripSeparator1
			//
			this.ToolStripSeparator1.Name = "ToolStripSeparator1";
			this.ToolStripSeparator1.Size = new System.Drawing.Size(114, 6);
			//
			//mnuPregled2
			//
			this.mnuPregled2.Name = "mnuPregled2";
			this.mnuPregled2.Size = new System.Drawing.Size(117, 22);
			this.mnuPregled2.Text = "Pregledi";
			//
			//mnuProdaja2
			//
			this.mnuProdaja2.Name = "mnuProdaja2";
			this.mnuProdaja2.Size = new System.Drawing.Size(117, 22);
			this.mnuProdaja2.Text = "Prodaja";
			//
			//StatusStrip1
			//
			this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {this.lblRM, this.lblRadnik, this.lblObj});
			this.StatusStrip1.Location = new System.Drawing.Point(0, 415);
			this.StatusStrip1.Name = "StatusStrip1";
			this.StatusStrip1.Size = new System.Drawing.Size(897, 22);
			this.StatusStrip1.TabIndex = 2;
			this.StatusStrip1.Text = "StatusStrip1";
			//
			//lblRM
			//
			this.lblRM.Name = "lblRM";
			this.lblRM.Size = new System.Drawing.Size(121, 17);
			this.lblRM.Text = "ToolStripStatusLabel1";
			//
			//lblRadnik
			//
			this.lblRadnik.Name = "lblRadnik";
			this.lblRadnik.Size = new System.Drawing.Size(640, 17);
			this.lblRadnik.Spring = true;
			this.lblRadnik.Text = "ToolStripStatusLabel2";
			//
			//lblObj
			//
			this.lblObj.Name = "lblObj";
			this.lblObj.Size = new System.Drawing.Size(121, 17);
			this.lblObj.Text = "ToolStripStatusLabel3";
			//
			//mnuKnjige
			//
			this.mnuKnjige.Name = "mnuKnjige";
			this.mnuKnjige.Size = new System.Drawing.Size(152, 22);
			this.mnuKnjige.Text = "Knjige";
			//
			//Form1
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6.0F, 13.0F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(897, 437);
			this.Controls.Add(this.StatusStrip1);
			this.Controls.Add(this.MenuStrip1);
			this.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			this.IsMdiContainer = true;
			this.MainMenuStrip = this.MenuStrip1;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Šta čitaš, tako i misliš ...";
			this.MenuStrip1.ResumeLayout(false);
			this.MenuStrip1.PerformLayout();
			this.StatusStrip1.ResumeLayout(false);
			this.StatusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

//INSTANT C# NOTE: Converted design-time event handler wireups:
			base.Load += new System.EventHandler(Form1_Load);
			ZaposleniToolStripMenuItem.Click += new System.EventHandler(ZaposleniToolStripMenuItem_Click);
			mnuKnjizare.Click += new System.EventHandler(ObjekatiToolStripMenuItem_Click);
			mnuMagacini.Click += new System.EventHandler(mnuMagacini_Click);
			mnuPromet.Click += new System.EventHandler(mnuPromet_Click);
			PreglediToolStripMenuItem.Click += new System.EventHandler(PreglediToolStripMenuItem_Click);
			this.Shown += new System.EventHandler(Form1_Shown);
			mnuPregled2.Click += new System.EventHandler(mnuPregled2_Click);
			mnuPromet2.Click += new System.EventHandler(mnuPromet2_Click);
			mnuAktivnosti.Click += new System.EventHandler(mnuAktivnosti_Click);
			mnuProdaja.Click += new System.EventHandler(mnuProdaja_Click);
			mnuProdaja2.Click += new System.EventHandler(mnuProdaja2_Click);
			mnuKnjige.Click += new System.EventHandler(mnuKnjige_Click);
		}
		internal System.Windows.Forms.MenuStrip MenuStrip1;
		internal System.Windows.Forms.ToolStripMenuItem PostavkaToolStripMenuItem;
		internal System.Windows.Forms.ToolStripMenuItem ZaposleniToolStripMenuItem;
		internal System.Windows.Forms.ToolStripMenuItem mnuMagacini;
		internal System.Windows.Forms.ToolStripMenuItem mnuKnjizare;
		internal System.Windows.Forms.ToolStripMenuItem mnuAktivnosti;
		internal System.Windows.Forms.ToolStripMenuItem mnuPromet;
		internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem1;
		internal System.Windows.Forms.ToolStripMenuItem PreglediToolStripMenuItem;
		internal System.Windows.Forms.ToolStripMenuItem mnuAktiv2;
		internal System.Windows.Forms.ToolStripMenuItem mnuPromet2;
		internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
		internal System.Windows.Forms.ToolStripMenuItem mnuPregled2;
		internal System.Windows.Forms.StatusStrip StatusStrip1;
		internal System.Windows.Forms.ToolStripStatusLabel lblRM;
		internal System.Windows.Forms.ToolStripStatusLabel lblRadnik;
		internal System.Windows.Forms.ToolStripStatusLabel lblObj;
		internal System.Windows.Forms.ToolStripMenuItem mnuProdaja;
		internal System.Windows.Forms.ToolStripMenuItem mnuProdaja2;
		internal System.Windows.Forms.ToolStripMenuItem mnuKnjige;

	}

}