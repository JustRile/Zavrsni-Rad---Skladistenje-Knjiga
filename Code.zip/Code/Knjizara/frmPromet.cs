﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;

namespace Knjizara
{
	public partial class frmPromet
	{
		public frmPromet()
		{
			InitializeComponent();
		}

		private DataTable m_Vrste;
		private string m_Error;

		private DataTable m_Stanje;
		private bool m_IsLoad = true;

		private int m_ActiveVrsta;
		private int m_ActiveObj;

		private enum EView
		{
			Stanje,
			Finansije,
			Dostavnica,
			Promet
		}

		private EView m_ViewOblik;
		private List<ToolStripButton> m_Buttons;

		private void SetCaption(int _Vrsta)
		{
			for (int i = 1; i <= 9; i++)
			{
				if (Form1.DefaultInstance.CaptionList.Keys.Contains(new Point(_Vrsta, i)))
				{
					string rr = null;
					Form1.DefaultInstance.CaptionList.TryGetValue(new Point(_Vrsta, i), out rr);
					m_Buttons[i].Text = rr; // Form1.DefaultInstance.CaptionList.Item(new Point(_Vrsta, i));
				}
			}
		}

		private void frmPromet_Load(System.Object sender, System.EventArgs e)
		{
			this.Icon = Form1.DefaultInstance.Icon;
			m_IsLoad = true;
			//m_Vrste = DB.GetData("SELECT * FROM VrstaRM where vrsta <> 6", m_Error)
			m_Buttons = new List<ToolStripButton>();
			m_Buttons.Add(null);
			m_Buttons.Add(mnuTreb);
			m_Buttons.Add(mnuPri);
			m_Buttons.Add(mnuOtp);
			m_Buttons.Add(mnuKomisija);
			m_Buttons.Add(mnuDost);
			m_Buttons.Add(null);
			m_Buttons.Add(mnuReklamacija);
			m_Buttons.Add(mnuUKnjizaru);

			m_Vrste = SrednjiSloj.Pravila.VratiSpisakVrstaRM(ref m_Error, 6);
			cboRM.DisplayMember = "naziv";
			cboRM.ValueMember = "vrsta";
			cboRM.DataSource = m_Vrste;
			cboRM.SelectedIndex = 0;
			cboRM_SelectedIndexChanged(cboRM, new EventArgs());
			m_IsLoad = false;
			if (cboObj.Items.Count > 0)
			{
				cboObj.SelectedIndex = 0;
				cboObj_SelectedIndexChanged(cboObj, new EventArgs());
			}

		}

		private void DisplayOptions(int _ID)
		{
			m_Error = null;
			//Dim tt As DataTable = DB.GetData("SELECT * FROM Moze(" + _ID.ToString + ")", m_Error)
			DataTable tt = SrednjiSloj.Pravila.VratiViewButtons(_ID, ref m_Error);
			if (m_Error == null)
			{
				if (tt.Rows.Count > 0)
				{
					string s = tt.Rows[0][1].ToString();
					for (int i = 1; i < ToolStrip1.Items.Count; i++)
					{
						ToolStrip1.Items[i].Tag = s.Substring(i - 1, 1);
						ToolStrip1.Items[i].Visible = (s.Substring(i - 1, 1) != "0");
					}
				}
				SetCaption(_ID);
			}
			else
			{
				MessageBox.Show(m_Error);
			}
		}
		private void cboRM_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (!m_IsLoad)
			{
				string porukica = "";
				if (cboRM.SelectedIndex > -1)
				{
					ClearGrid();
					lblOpcija.Text = "Stanje";
					m_ActiveVrsta = Convert.ToInt32(cboRM.SelectedValue.ToString());
					m_ActiveObj = 0;

					DisplayOptions(Convert.ToInt32(cboRM.SelectedValue));
					m_Error = null;
					//Dim tt As DataTable = DB.GetData("SELECT * FROM Moze(" + cboRM.SelectedValue.ToString + ")", m_Error)
					DataTable tt = SrednjiSloj.Pravila.VratiViewButtons(Convert.ToInt32(cboRM.SelectedValue), ref m_Error);
					if (m_Error == null)
					{
						if (tt.Rows.Count > 0)
						{

						}
					}
					else
					{
						MessageBox.Show(m_Error);
						return;
					}
					lblObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
					cboObj.Visible = (Convert.ToInt32(cboRM.SelectedValue) < 3);
					if (Convert.ToInt32(cboRM.SelectedValue) == 1)
					{
						lblObj.Text = "Knjižara";
						cboObj.ValueMember = "objid";
						cboObj.DisplayMember = "naziv";
						string gr = null;
						cboObj.DataSource = SrednjiSloj.Pravila.VratiKnjizareZaMagacin(0, ref gr);
					}
					else if (Convert.ToInt32(cboRM.SelectedValue) == 2)
					{
						lblObj.Text = "Magacin";
						cboObj.ValueMember = "objid";
						cboObj.DisplayMember = "naziv";
						string gr = null;
						cboObj.DataSource = SrednjiSloj.Pravila.VratiSpisakMagacina(ref gr);
					}
					else if (Convert.ToInt32(cboRM.SelectedValue) == 3)
					{
						//m_Stanje = DB.GetData("SELECT * FROM PrometZa(" + cboRM.SelectedValue.ToString + ")", m_Error)
						m_Stanje = SrednjiSloj.Pravila.VratiPrometZaObjekat(Convert.ToInt32(cboRM.SelectedValue), ref m_Error);
						m_ViewOblik = EView.Finansije;
						dgStanje.DataSource = m_Stanje;
						FormatGrid(m_ViewOblik);
						if (!(m_Stanje == null))
						{
							if (m_Stanje.Rows .Count ==0)
							{
								MessageBox.Show("Nema finansijskih podataka za pregled.");
								return;
							}
						}

					}
					else if (Convert.ToInt32(cboRM.SelectedValue) == 4)
					{
						//m_Stanje = DB.GetData("SELECT * FROM PrometZa(" + cboRM.SelectedValue.ToString + ")", m_Error)
						m_Stanje = SrednjiSloj.Pravila.VratiPrometZaObjekat(Convert.ToInt32(cboRM.SelectedValue), ref m_Error);
						m_ViewOblik = EView.Finansije;
						dgStanje.DataSource = m_Stanje;
						FormatGrid(m_ViewOblik);
						if (!(m_Stanje == null))
						{
							if (m_Stanje.Rows.Count == 0)
							{
								MessageBox.Show("Nema finansijskih podataka za pregled.");
								return;
							}
						}
					}
					else if (Convert.ToInt32(cboRM.SelectedValue) == 5)
					{
						m_Stanje = SrednjiSloj.Pravila.VratiViewData(m_ActiveObj, m_ActiveVrsta, ref m_Error);
						//m_Stanje = DB.GetData("SELECT * FROM PrometZa(" + cboRM.SelectedValue.ToString + ")", m_Error)
						m_ViewOblik = EView.Dostavnica;
						dgStanje.DataSource = m_Stanje;
						FormatGrid(m_ViewOblik);
						if (!(m_Stanje == null))
						{
							if (m_Stanje.Rows.Count == 0)
							{
								MessageBox.Show("Nema kreiranih prijemnica u sistemu.","NEMA PODATAKA");
								return;
							}
						}
					}
				}
				SetCaption(m_ActiveVrsta);
			}
		}

		private void cboObj_SelectedIndexChanged(System.Object sender, System.EventArgs e)
		{
			if (!m_IsLoad)
			{
				string porukica ="";
				if (Convert.ToInt32(cboRM.SelectedValue) == 1)
				{
					//m_Stanje = DB.GetData("SELECT * FROM Stanje(" + cboObj.SelectedValue.ToString + ")", m_Error)
					m_Stanje = SrednjiSloj.Pravila.VratiStanjeZaObjekat(Convert.ToInt32(cboObj.SelectedValue), ref m_Error);

					m_ActiveObj = Convert.ToInt32(cboObj.SelectedValue);
					m_ViewOblik = EView.Stanje;
					porukica = "Ne postoje evidentirane knjige u knjižari.Unesite knjige u evidenciju.";
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 2)
				{
					//m_Stanje = DB.GetData("SELECT * FROM Stanje(" + cboObj.SelectedValue.ToString + ")", m_Error)
					m_Stanje = SrednjiSloj.Pravila.VratiStanjeZaObjekat(Convert.ToInt32(cboObj.SelectedValue), ref m_Error);
					m_ActiveObj = Convert.ToInt32(cboObj.SelectedValue);
					m_ViewOblik = EView.Stanje;
					porukica = "Ne postoje evidentirane knjige u magacinu. Unesite knige u evidenciju.";
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 3)
				{
					m_ViewOblik = EView.Finansije;
					porukica = "Nema finansijskih dokumenata za pregled.";
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 4)
				{
					m_ViewOblik = EView.Finansije;
					porukica = "Nema finansijskih dokumenata za pregled.";
				}
				else if (Convert.ToInt32(cboRM.SelectedValue) == 5)
				{
					m_ViewOblik = EView.Finansije;
					porukica = "Nema finansijskih dokumenata za pregled.";
				}
	
				dgStanje.DataSource = m_Stanje;
				FormatGrid(m_ViewOblik);
				if (!(m_Stanje == null))
				{ 
				if(m_Stanje .Rows .Count == 0)
					{
						MessageBox.Show(porukica, "NEMA PODATAKA");
					}
				}
			}
		}

		public DataTable DisplayDocs(int _Vrsta, int _ObjID, ref string _Error)
		{
			return SrednjiSloj.Pravila.VratiViewData(_ObjID, _Vrsta, ref _Error);
		}

		public void ClickMe(object sender, EventArgs e)
		{
			ToolStripItem mnu = (ToolStripItem)sender;
			if (mnu.Tag.ToString() == "2")
			{

			}
		}

		private void mnuTreb_Click(System.Object sender, System.EventArgs e)
		{
			DataTable t = SrednjiSloj.Pravila.VratiSpisakKnjiga(ref m_Error);

			if (!(t == null))
			{
				if (t.Rows.Count == 0)
				{
					MessageBox.Show("Magacin je prazan. Morate uneti knjige u magacin.", "PRAZAN MAGACIN");
					this.Close();
					return;
				}
			}
			lblOpcija.Text = mnuTreb.Text;
			if (m_ActiveVrsta == 1)
			{
				m_Error = null;
				try
				{
					//Dim k As Integer = DB.GetValue("SELECT dbo.MagacinZa(" + m_ActiveObj.ToString + ")", m_Error)
					int k = SrednjiSloj.Pravila.VratiMagacinZaKnjizaru(m_ActiveObj, ref m_Error);
					frmDoc f = new frmDoc();
					f.Init(1, m_ActiveVrsta, m_ActiveObj, 2, k, "Trebovanje");
					f.ShowDialog();
					f.Close();
					f.Dispose();
					f = null;
					ShowStanje(cboRM.SelectedIndex, cboObj.SelectedIndex);
				}
				catch (Exception ex)
				{
					if (m_Error != null)
					{
						MessageBox.Show(m_Error + "\r\n" + ex.Message);
					}
					else
					{
						MessageBox.Show(ex.Message);
					}

				}
			}
			else if (m_ActiveVrsta == 2)
			{
				m_Stanje = DisplayDocs(m_ActiveVrsta, m_ActiveObj, ref m_Error);
				m_Stanje.DefaultView.RowFilter = "vrstadoc = 1";
				dgStanje.DataSource = m_Stanje;
				m_ViewOblik = EView.Promet;
				FormatGrid(m_ViewOblik);
			}
			else //samo čitanje
			{
				m_Error = null;
				int k = m_ActiveObj; // DB.GetValue("SELECT dbo.MagacinZa(" + m_ActiveObj.ToString + ")", m_Error)

				frmDoc f = new frmDoc();
				//Dim tt As DataTable = DB.GetData("SELECT * FROM ZaPrijemnicu(" + k.ToString + ")", m_Error)
				DataTable tt = SrednjiSloj.Pravila.VratiSpisakPrijemnica(k, ref m_Error);
				f.InitData(ref tt);
				f.Init(2, m_ActiveVrsta, m_ActiveObj, 5, 0, "Za prijemnicu");
				f.ShowDialog();
				f.Close();
				f.Dispose();
				f = null;

				int kk = -1;
				if (cboObj.Visible)
				{
					kk = cboObj.SelectedIndex;
				}
				ShowStanje(cboRM.SelectedIndex, kk);
			}
		} 

		private void mnuPri_Click(System.Object sender, System.EventArgs e)
		{

			if (m_ActiveVrsta == 2)
			{
				if (dgStanje.CurrentRow != null)
				{
					if (!dgStanje.Columns.Contains("status"))
					{
						return;
					}
					if (dgStanje.CurrentRow.Cells["status"].Value.ToString() != "1")
					{
						MessageBox.Show("Za ovu prijemnicu je već poslat zahtev dobavljaču.");
						return;
					}
				}
				DataTable tt = SrednjiSloj.Pravila.VratiSpisakPrijemnica(m_ActiveObj, ref m_Error);

				if (tt.Rows.Count > 0)
				{
					frmDoc f = new frmDoc();
					f.InitData(ref tt);
					f.Init(2, m_ActiveVrsta, m_ActiveObj, 5, 0, "Otpremnica dobavljača");
					f.ShowDialog();
					f.Close();
					f.Dispose();
					f = null;
				}
				else
				{
					MessageBox.Show("Prijemnica nije kreirana u sistemu.", "NEMA KRERANIH PRIJEMNICA");
					return;
				}
				int kk = -1;
				if (cboObj.Visible)
				{
					kk = cboObj.SelectedIndex;
				}
				lblOpcija.Text = mnuPri.Text;
				ShowStanje(cboRM.SelectedIndex, kk);
			}
			else if (m_ActiveVrsta == 5)
			{
				m_Stanje = DisplayDocs(m_ActiveVrsta, 0, ref m_Error);
				if (!(m_Stanje == null))
					{
					if (m_Stanje .Rows .Count == 0)
					{
						MessageBox.Show("Prijemnica nije kreirana u sitemu.", "NEMA PODATAKA");
						return;
					}
				}
				m_Stanje.DefaultView.RowFilter = "vrstadoc = 2";
				dgStanje.DataSource = m_Stanje;
				m_ViewOblik = EView.Dostavnica;
				FormatGrid(m_ViewOblik);
			}
		}

		private void mnuOtp_Click(System.Object sender, System.EventArgs e)
		{

			if (m_ActiveVrsta == 5)
			{
				if (dgStanje.CurrentRow != null)
				{
					//Dim tt As DataTable = DB.GetData("SELECT * FROM DocStavke(" + dgStanje.CurrentRow.Cells(0).Value.ToString + ")", m_Error)
					//Dim aa As DataTable = DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + dgStanje.CurrentRow.Cells(0).Value.ToString, m_Error)

					DataTable tt = SrednjiSloj.Pravila.VratiStavkeDokumenta(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
					DataTable aa = SrednjiSloj.Pravila.VratiPodatkeODokumentu(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
					int a = 0;

					if (aa.Rows.Count > 0)
					{
						a = Convert.ToInt32(aa.Rows[0]["objiz"].ToString());
					}
					frmDoc f = new frmDoc();
					f.InitData(ref tt);
					f.Init(3, m_ActiveVrsta, m_ActiveObj, 2, a, "Otpremnica dobavljača");
					f.ShowDialog();
					if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
					{
						lblOpcija.Text = mnuOtp.Text;
					}
					f.Close();
					f.Dispose();
					f = null;
					int kk = -1;
					if (cboObj.Visible)
					{
						kk = cboObj.SelectedIndex;
					}
					ShowStanje(cboRM.SelectedIndex, kk);
				}
				else
				{
					MessageBox.Show("Ne postoje prijemnice za koje bi se kreirala otpremnica..", "NEMA PODATAKA");
					return;
				}
			}
			else if (m_ActiveVrsta == 2)
			{
				m_Stanje = SrednjiSloj.Pravila.VratiViewData(m_ActiveObj, m_ActiveVrsta, ref m_Error);
				m_Stanje.DefaultView.RowFilter = "vrstadoc = 3";
				dgStanje.DataSource = m_Stanje;
				lblOpcija.Text = mnuOtp.Text;
				m_ViewOblik = EView.Promet;
				FormatGrid(m_ViewOblik);
				if (!(m_Stanje == null))
				{
					if (m_Stanje.DefaultView.Count  == 0)
					{
						MessageBox.Show("Ne postoje prijemnice za koje bi se kreirala otpremnica..", "NEMA PODATAKA");
						return;
					}
				}
			}
			else
			{

			}
		}

		private void mnuKomisija_Click(System.Object sender, System.EventArgs e)
		{
			if (lblOpcija.Text == mnuOtp.Text)
			{
				if (dgStanje.CurrentRow != null)
				{
					lblOpcija.Text = mnuKomisija.Text;

					//Dim tt As DataTable = DB.GetData("SELECT * FROM DocStavke(" + dgStanje.CurrentRow.Cells(0).Value.ToString + ")", m_Error)
					//Dim aa As DataTable = DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + dgStanje.CurrentRow.Cells(0).Value.ToString, m_Error)

					DataTable tt = SrednjiSloj.Pravila.VratiStavkeDokumenta(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
					DataTable aa = SrednjiSloj.Pravila.VratiPodatkeODokumentu(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
					//Dim a As Integer = 0

					//If aa.Rows.Count > 0 Then
					//    a = CInt(aa.Rows(0).Item("objiz").ToString)
					//End If
					if (!(tt == null))
					{
						if (tt.Rows .Count == 0)
						{
							MessageBox.Show("Ne postoje izabrane stavke za traženu otpremnicu.", "NEMA PODATAKA");
							return;
						}
					}
					frmDoc f = new frmDoc();
					f.InitData(ref tt);
					f.Init(4, m_ActiveVrsta, m_ActiveObj, m_ActiveVrsta, m_ActiveObj, "Komisioni zapisnik");
					f.ShowDialog();
					f.Close();
					f.Dispose();
					f = null;
					int kk = -1;
					if (cboObj.Visible)
					{
						kk = cboObj.SelectedIndex;
					}
					ShowStanje(cboRM.SelectedIndex, kk);
				}
			}

		}

		private void mnuUKnjizaru_Click(System.Object sender, System.EventArgs e)
		{

			if (m_ActiveVrsta == 1)
			{
				if (dgStanje.CurrentRow != null)
				{
					if (lblOpcija.Text == mnuTreb.Text)
					{

						//Dim tt As DataTable = DB.GetData("SELECT * FROM DocStavke(" + dgStanje.CurrentRow.Cells(0).Value.ToString + ")", m_Error)
						//Dim aa As DataTable = DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + dgStanje.CurrentRow.Cells(0).Value.ToString, m_Error)

						DataTable tt = SrednjiSloj.Pravila.VratiStavkeDokumenta(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
						DataTable aa = SrednjiSloj.Pravila.VratiPodatkeODokumentu(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
						int a = 0;

						if (aa.Rows.Count > 0)
						{
							a = Convert.ToInt32(aa.Rows[0]["objiz"].ToString());
						}
						else
						{
							MessageBox.Show("Ne postoji dostavnica sa koje bi se primile knjige.", "NEMA DOSTAVNICE");
							return;
						}
						frmDoc f = new frmDoc();
						f.InitData(ref tt);
						f.Init(2, 2, 1, m_ActiveVrsta, m_ActiveObj, "Prijemnica knjižare");
						f.ShowDialog();
						if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
						{
							lblOpcija.Text = mnuUKnjizaru.Text;
						}
						f.Close();
						f.Dispose();
						f = null;
						int kk = -1;
						if (cboObj.Visible)
						{
							kk = cboObj.SelectedIndex;
						}
						ShowStanje(cboRM.SelectedIndex, kk);
					}
					else if (lblOpcija.Text == mnuDost.Text)
					{
						//Dim tt As DataTable = DB.GetData("SELECT * FROM DocStavke(" + dgStanje.CurrentRow.Cells(0).Value.ToString + ")", m_Error)
						//Dim aa As DataTable = DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + dgStanje.CurrentRow.Cells(0).Value.ToString, m_Error)

						DataTable tt = SrednjiSloj.Pravila.VratiStavkeDokumenta(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
						DataTable aa = SrednjiSloj.Pravila.VratiPodatkeODokumentu(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);
						int a = 0;

						if (aa.Rows.Count > 0)
						{
							a = Convert.ToInt32(aa.Rows[0]["objiz"].ToString());
						}
						frmDoc f = new frmDoc();
						f.InitData(ref tt);
						f.Init(2, m_ActiveVrsta, m_ActiveObj, m_ActiveVrsta, m_ActiveObj, "Prijemnica knjižare");
						f.ShowDialog();
						if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
						{
							lblOpcija.Text = mnuUKnjizaru.Text;
						}
						f.Close();
						f.Dispose();
						f = null;
						int kk = -1;
						if (cboObj.Visible)
						{
							kk = cboObj.SelectedIndex;
						}
						ShowStanje(cboRM.SelectedIndex, kk);
					}
				}
		else
				{
					MessageBox.Show("Nemate knjige za prijem.", "KNJIGE U KNJIŽARU");
					return;
				}
			}
		}

		private void mnuDost_Click(System.Object sender, System.EventArgs e)
		{


			if (m_ActiveVrsta == 2)
			{
				if (lblOpcija.Text == mnuTreb.Text)
				{
					if (dgStanje.CurrentRow != null)
					{
						//Dim tt As DataTable = DB.GetData("SELECT * FROM DocStavke(" + dgStanje.CurrentRow.Cells(0).Value.ToString + ")", m_Error)
						int currDoc = 0;
						//Dim aa As DataTable = DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + dgStanje.CurrentRow.Cells(0).Value.ToString, m_Error)
						DataTable aa = SrednjiSloj.Pravila.VratiPodatkeODokumentu(Convert.ToInt32(dgStanje.CurrentRow.Cells[0].Value), ref m_Error);

						int a = 0;
						int b = 0;

						if (aa.Rows.Count > 0)
						{
							currDoc = Convert.ToInt32(aa.Rows[0]["docid"].ToString());
							a = Convert.ToInt32(aa.Rows[0]["obju"].ToString());
							b = Convert.ToInt32(aa.Rows[0]["objiz"].ToString());
						}
						else
						{
							MessageBox.Show("Nemate dostavnica za prijem.", "NEMA PODATAKA");
							return;
						}
						DataTable ttt = SrednjiSloj.Pravila.SinhroTrebovanje(currDoc, a, ref m_Error);
						ttt.DefaultView.RowFilter = "komada > 0";
						DataTable tt = ttt.DefaultView.ToTable();

						frmDoc f = new frmDoc();
						f.InitData(ref tt);
						f.Init(5, m_ActiveVrsta, m_ActiveObj, 1, b, "Dostavnica za knjižaru");
						f.ShowDialog();
						if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
						{
							lblOpcija.Text = mnuDost.Text;
						}
						f.Close();
						f.Dispose();
						f = null;
						int kk = -1;
						if (cboObj.Visible)
						{
							kk = cboObj.SelectedIndex;
						}
						ShowStanje(cboRM.SelectedIndex, kk);
					}
				}
			}
			else if (m_ActiveVrsta == 1)
			{
				m_Stanje = DisplayDocs(m_ActiveVrsta, m_ActiveObj, ref m_Error);
				m_Stanje.DefaultView.RowFilter = "vrstadoc = 5";
				dgStanje.DataSource = m_Stanje;
				lblOpcija.Text = mnuDost.Text;
				m_ViewOblik = EView.Promet;
				FormatGrid(m_ViewOblik);
				if (!(m_Stanje == null))
				{
					if (m_Stanje .DefaultView .Count == 0)
					{
						MessageBox.Show("Nemate dostavnica za prijem.", "NEMA PODATAKA");
						return;

					}
				}
			}
		}

		private void mnuReklamacija_Click(System.Object sender, System.EventArgs e)
		{

		}

		private void mnuUExcel_Click(System.Object sender, System.EventArgs e)
		{
			if (dgStanje.CurrentRow != null)
			{
				if (dgStanje.Columns.Contains("docid"))
				{
					int docid = Convert.ToInt32(dgStanje.CurrentRow.Cells["docid"].Value);
					//Dim ttt As DataTable = DB.GetData("SELECT * FROM Dokumenta where docid = " + docid.ToString, m_Error)
					DataTable ttt = SrednjiSloj.Pravila.VratiPodatkeODokumentu(docid, ref m_Error);

					int objiz = Convert.ToInt32(ttt.Rows[0]["objiz"]);
					int obju = Convert.ToInt32(ttt.Rows[0]["obju"]);
					int vrstadoc = Convert.ToInt32(ttt.Rows[0]["vrstadoc"]);
					modMain.Objekat iz = new modMain.Objekat();
					modMain.Objekat u = new modMain.Objekat();

					if (vrstadoc == 6)
					{
						int cc = objiz;
						objiz = obju;
						obju = cc;
					}
					m_Error = null;
					if (objiz == 0)
					{
						iz.Naziv = "Moj dobavljač";
						iz.Adresa = "Adresa dobavljača";
						iz.Mesto = "PTT + Mesto dobavljača";
					}
					else
					{
						//Dim a As DataTable = DB.GetData("SELECT * FROM Objekti WHERE objid = " + objiz.ToString, m_Error)
						DataTable a = SrednjiSloj.Pravila.VratiObjekatInfo(objiz, ref m_Error);
						iz.Naziv = a.Rows[0]["naziv"].ToString();
						iz.Adresa = a.Rows[0]["adresa"].ToString();
						iz.Mesto = a.Rows[0]["mesto"].ToString();
					}
					if (obju == 0)
					{
						u.Naziv = "Moj dobavljač";
						u.Adresa = "Adresa dobavljača";
						u.Mesto = "PTT + Mesto dobavljača";
					}
					else
					{
						//Dim aa As DataTable = DB.GetData("SELECT * FROM Objekti WHERE objid = " + obju.ToString, m_Error)
						DataTable aa = SrednjiSloj.Pravila.VratiObjekatInfo(obju, ref m_Error);
						u.Naziv = aa.Rows[0]["naziv"].ToString();
						u.Adresa = aa.Rows[0]["adresa"].ToString();
						u.Mesto = aa.Rows[0]["mesto"].ToString();
					}
                    int vd = (int)ttt.Rows[0]["vrstadoc"];
                    string doc = SrednjiSloj.Pravila.Vrednost("SELECT dokument FROM VrstaDoc where vrstadoc = " + vd.ToString(), ref m_Error).ToString ();
					DateTime dat = Convert.ToDateTime(ttt.Rows[0]["datum"]);
					string oznaka = ttt.Rows[0]["oznaka"].ToString();
					decimal izn = Convert.ToDecimal(ttt.Rows[0]["iznos"]);
					string ssql = "select ROW_NUMBER () OVER(ORDER BY Naslov) Rb,ISBN,Naslov,Autor,Cena,Komada,Cena*Komada Iznos from DocStavke(" + docid.ToString() + ")";
					string opis = "";
					if (ttt.Rows[0]["vrstadoc"].ToString() == "6")
					{
						DataTable kk = SrednjiSloj.Pravila.VratiReklamacijuZaOtpremnicu(Convert.ToInt32(docid.ToString()), ref m_Error);
						if (kk.Rows.Count > 0)
						{
							opis = "Vezni dokument: " + kk.Rows[0]["dokument"].ToString() + " broj " + kk.Rows[0]["oznaka"].ToString();
						}
					}
					DataTable hh = SrednjiSloj.Pravila.DetaljiRacuna  (ssql, ref m_Error);
					modMain.BookDoc(iz, u, doc, oznaka, opis, dat, izn, hh, doc, Application.StartupPath + "\\" + doc + " " + oznaka.Replace("\\", "_") + ".xlsx");

				}
			}
		}

		private void ClearGrid()
		{
			dgStanje.DataSource = null;
			dgStanje.Rows.Clear();
			dgStanje.Columns.Clear();
		}

		private void FormatGrid(EView _Oblik)
		{
			if (_Oblik == EView.Stanje)
			{
				dgStanje.Columns[0].Visible = false;
				dgStanje.Columns[1].Visible = false;
				dgStanje.Columns[2].Visible = true;
				dgStanje.Columns[3].Visible = true;
				dgStanje.Columns[4].Visible = true;
				dgStanje.Columns[5].Visible = true;

				dgStanje.Columns[2].HeaderText = "ISBN";
				dgStanje.Columns[3].HeaderText = "Naslov";
				dgStanje.Columns[4].HeaderText = "Autor";
				dgStanje.Columns[5].HeaderText = "Stanje";
				dgStanje.Columns[5].DefaultCellStyle.Format = "N0";
				dgStanje.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			}
			else if (_Oblik == EView.Finansije)
			{
				dgStanje.Columns[0].Visible = false;
				dgStanje.Columns[1].Visible = true;
				dgStanje.Columns[2].Visible = true;
				dgStanje.Columns[3].Visible = true;
				dgStanje.Columns[4].Visible = true;
				dgStanje.Columns[5].Visible = true;
				dgStanje.Columns[6].Visible = true;
				dgStanje.Columns[7].Visible = true;

				dgStanje.Columns[1].HeaderText = "Datum";
				dgStanje.Columns[2].HeaderText = "Dokument";
				dgStanje.Columns[3].HeaderText = "Oznaka";
				dgStanje.Columns[4].HeaderText = "Zahtevano";
				dgStanje.Columns[5].HeaderText = "Uplaćeno";
				dgStanje.Columns[4].HeaderText = "Ispravno";
				dgStanje.Columns[5].HeaderText = "Povraćaj";

				dgStanje.Columns[4].DefaultCellStyle.Format = "N2";
				dgStanje.Columns[5].DefaultCellStyle.Format = "N2";
				dgStanje.Columns[6].DefaultCellStyle.Format = "N2";
				dgStanje.Columns[7].DefaultCellStyle.Format = "N2";
				dgStanje.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
				dgStanje.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
				dgStanje.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
				dgStanje.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

			}
			else if (_Oblik == EView.Dostavnica)
			{
				dgStanje.Columns[0].Visible = false;
				dgStanje.Columns[1].Visible = false;
				dgStanje.Columns[2].Visible = true;
				dgStanje.Columns[3].Visible = true;
				dgStanje.Columns[4].Visible = true;
				dgStanje.Columns[5].Visible = true;
				dgStanje.Columns[6].Visible = true;
				dgStanje.Columns[7].Visible = true;


				dgStanje.Columns[2].HeaderText = "Dokument";
				dgStanje.Columns[3].HeaderText = "Oznaka";
				dgStanje.Columns[4].HeaderText = "Naziv";
				dgStanje.Columns[5].HeaderText = "Datum";
				dgStanje.Columns[6].HeaderText = "Iznos";
				dgStanje.Columns[6].DefaultCellStyle.Format = "N2";
				dgStanje.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
				dgStanje.Columns[7].HeaderText = "Status";
			}
			else if (_Oblik == EView.Promet)
			{
				dgStanje.Columns[0].Visible = false;
				dgStanje.Columns[1].Visible = false;
				dgStanje.Columns[2].Visible = true;
				dgStanje.Columns[3].Visible = true;
				dgStanje.Columns[4].Visible = true;
				dgStanje.Columns[5].Visible = true;
				dgStanje.Columns[6].Visible = true;
				dgStanje.Columns[7].Visible = true;
			}
		}

		private void ShowStanje(int _I1, int _I2)
		{
			cboRM.SelectedIndex = _I1;
			cboRM_SelectedIndexChanged(cboRM, new EventArgs());
			if (_I2 > -1)
			{
				cboObj.SelectedIndex = _I2;
				cboObj_SelectedIndexChanged(cboObj, new EventArgs());
			}
		}
	}
}