﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace SrednjiSloj
{
    interface IDomenskiObjekat
    {
        bool Connect(ref string _Error);
        bool Disconnect(ref string _Error);
        DataTable GetData(string _SQL, ref string _Error);
        DataTable GetData(System.Data.SqlClient.SqlCommand _SQL, ref string _Error);
        DataSet GetDS(string _SQL, ref string _Error);
        DataSet GetDS(System.Data.SqlClient.SqlCommand _SQL, ref string _Error);
        bool Execute(string _SQL, ref string _Error);
        bool Execute(System.Data.SqlClient.SqlCommand _SQL, ref string _Error);
        object GetValue(string _SQL, ref string _Error);
    }
}
