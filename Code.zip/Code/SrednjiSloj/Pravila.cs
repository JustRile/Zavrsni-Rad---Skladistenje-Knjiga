﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Xml.Linq;

namespace SrednjiSloj
{
	public class Pravila : IDomenskiObjekat
	{
		public enum ERMesta
		{
			Prodavac = 0,
			Magacioner = 1,
			Uprava = 2,
			Finansije = 3,
			Dobavljac = 4
		}

		public static int EmpID { get; set; }
		private static IDomenskiObjekat m_DB;
		private static string StrA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvxyz0123456789.,;!?@:-_";
		private static string StrB = "qrstuJ?@:-_mnopLMNOPQRSabTUV89.,;EFGABCDK!WXYZc456defghijklvxyz01237HI";

		private static string Crypt(string _Source)
		{
			string fja = "";
			for (int i = 0; i < _Source.Count(); i++)
			{
				string slovo = _Source.Substring(i, 1);
				if (StrA.IndexOf(slovo) >= 0)
				{
					fja += StrB.Substring(_Source.IndexOf(slovo), 1);
				}
				else
				{
					fja += slovo;
				}
			}
			return fja;
		}

		private static string Decrypt(string _Source)
		{
			string fja = "";
			for (int i = 0; i < StrB.Count(); i++)
			{
				if (StrB.Contains(_Source.Substring(i, 1)))
				{
					fja = StrA.Substring(StrB.IndexOf(_Source.Substring(i, 1)), 1);
				}
				else
				{
					fja += StrB.Substring(i, 1);
				}
			}
			return fja;
		}

		public static bool ObradaDokumenta(ref int _DocID, int _VrstaDoc, int _ObjIz, int _VrstaIz, int _ObjU, int _VrstaU, DateTime _Datum, ref int _Broj, ref string _Oznaka, decimal _Iznos, string _Status, ref string _Error)
		{

			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("DokumentaWork");
			comm.CommandType = CommandType.StoredProcedure;

			comm.Parameters.AddWithValue("@docid", _DocID);
			comm.Parameters.AddWithValue("@vrstadoc", _VrstaDoc);
			comm.Parameters.AddWithValue("@objiz", _ObjIz);
			comm.Parameters.AddWithValue("@vrstaiz", _VrstaIz);
			comm.Parameters.AddWithValue("@obju", _ObjU);
			comm.Parameters.AddWithValue("@vrstau", _VrstaU);
			comm.Parameters.AddWithValue("@datum", Convert.ToDateTime(_Datum));
			comm.Parameters.AddWithValue("@broj", _Broj);
			comm.Parameters.AddWithValue("@oznaka", _Oznaka);
			comm.Parameters.AddWithValue("@iznos", (decimal)_Iznos);
			comm.Parameters.AddWithValue("@status", _Status);
			comm.Parameters.AddWithValue("@empid", EmpID);
			DataTable tt = m_DB.GetData(comm, ref _Error);
			if (_Error == null)
			{
				if (tt.Rows.Count > 0)
				{
					_DocID = Convert.ToInt32(tt.Rows[0][0]);
					_Broj = Convert.ToInt32(tt.Rows[0]["broj"]);
					_Oznaka = tt.Rows[0]["oznaka"].ToString();
					return true;
				}
				else
				{
					_Error = "No data.";
					return false;
				}
			}
			else
			{
				return false;
			}
		}

		public static bool DodajStranu(int _DocID, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("DodajStranu");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@docid", _DocID);
			return m_DB.Execute(comm, ref _Error);
		}

		public static bool EvidentirajPromet(int _DocID, int _BookID, int _Komada, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("PrometWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@docid", _DocID);
			comm.Parameters.AddWithValue("@bookid", _BookID);
			comm.Parameters.AddWithValue("@komada", _Komada);
			return m_DB.Execute(comm, ref _Error);
		}

		public static DataTable VratiViewData(int _ObjID, int _Vrsta, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("ViewData");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@vrsta", _Vrsta);
			comm.Parameters.AddWithValue("@objid", _ObjID);
			return m_DB.GetData(comm, ref _Error);
		}

		public static bool AzurIznos(int _DocID, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("AzurStanje");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@docid", _DocID);
			return m_DB.Execute(comm, ref _Error);
		}

		public static bool PoveziDokumenta(int _DocIz, int _DocU, int _OPcija, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("VezaWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@dociz", _DocIz);
			comm.Parameters.AddWithValue("@docu", _DocU);
			comm.Parameters.AddWithValue("@opcija", _OPcija);
			return m_DB.Execute(comm, ref _Error);
		}

		public static bool MakeReklamacija(int _DocID, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("MakeReklamacija");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@docid", _DocID);
			return m_DB.Execute(comm, ref _Error);
		}

		public static DataTable SinhroTrebovanje(int _DocID, int _Magacin, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("SinhroTrebovanje");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@docid", _DocID);
			comm.Parameters.AddWithValue("@magacin", _Magacin);
			return m_DB.GetData(comm, ref _Error);
		}

		public static bool UpdateStatusDokumenta(int _DocID, string _Status, ref string _Error)
		{
			string s = "UPDATE Dokumenta Set Status = '" + _Status + "' WHERE docid = " + _DocID.ToString();
			return m_DB.Execute(s, ref _Error);
		}

		public static bool JednaStrana(int _DocID, int _ObjID, int _Vrsta, int _DP, ref string _Error)
		{
			string s = "INSERT INTO Strana SELECT " + _DocID.ToString() + "," + _ObjID.ToString() + "," + _Vrsta.ToString() + "," + _DP.ToString();
			return m_DB.Execute(s, ref _Error);
		}

		public static DataTable VratiReklamacijuZaOtpremnicu(int _DocID, ref string _Error)
		{
			string s = "select * from OtpremnicaReklamacije(" + _DocID.ToString() + ")";
			return m_DB.GetData(s, ref _Error);
		}

		public static DataTable VratiListuDokumenata(int _ObjID, int _Vrsta, DateTime _FromDate, DateTime _ToDate, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("previewdoc");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@vrsta", _Vrsta);
			comm.Parameters.AddWithValue("@objid", _ObjID);
			comm.Parameters.AddWithValue("@oddana", _FromDate);
			comm.Parameters.AddWithValue("@dodana", _ToDate);
			return m_DB.GetData(comm, ref _Error);
		}

		public static DataTable ObradaZaposlenog(int _ID, int _RM, int _Objekat, string _Ime, string _Sifra, string _Vazi, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("ZaposleniWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@empid", _ID);
			comm.Parameters.AddWithValue("@vrsta", _RM);
			comm.Parameters.AddWithValue("@objid", _Objekat);
			comm.Parameters.AddWithValue("@ime", _Ime);
			comm.Parameters.AddWithValue("@sifra", _Sifra);
			comm.Parameters.AddWithValue("@vazi", _Vazi);
			return m_DB.GetData(comm, ref _Error);
		}

		public static bool UpdatePWD(int _ID, string _PWD, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("UpdateLogin");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@empid", _ID);
			_PWD = Crypt(_PWD);
			comm.Parameters.AddWithValue("@newpwd", _PWD);
			DataTable tbl = m_DB.GetData(comm, ref _Error);
			if (_Error == null)
			{
				if (tbl.Rows.Count == 0)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
			else
			{
				return false;
			}
		}

		public static bool IsUserValid(string _Login, string _PWD, ref string _Error)
		{
			bool fja = false;
			if (_Login == "admin" && _PWD == "Maestro")
			{
				fja = true;
			}
			else
			{
				if (_Login != _PWD)
				{
					_PWD = Crypt(_PWD);
				}
				if (Convert.ToInt32(m_DB.GetValue("SELECT dbo.IsUserValid('" + _Login + "','" + _PWD + "')", ref _Error)) == 1)
				{
					EmpID = Convert.ToInt32(m_DB.GetValue("SELECT empid from Zaposleni where sifra = '" + _Login + "' And vazi = '1'", ref _Error));
					fja = true;
				}
				else
				{
					fja = false;
				}
			}
			return fja;
		}

		//IZ PODACI
		public static DataTable EvidentirajMagacin(int _ID, string _Sifra, string _Naziv, string _Adresa, string _Mesto, string _Vazi, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("ObjektiWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@objid", _ID);
			comm.Parameters.AddWithValue("@objvrsta", 2);
			comm.Parameters.AddWithValue("@pripada", 0);
			comm.Parameters.AddWithValue("@sifra", _Sifra);
			comm.Parameters.AddWithValue("@naziv", _Naziv);
			comm.Parameters.AddWithValue("@adresa", _Adresa);
			comm.Parameters.AddWithValue("@mesto", _Mesto);
			comm.Parameters.AddWithValue("@vazi", _Vazi);
			return m_DB.GetData(comm, ref _Error);
		}

		public static DataTable EvidentirajKnjizaru(int _ID, int _Magacin, string _Sifra, string _Naziv, string _Adresa, string _Mesto, string _Vazi, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("ObjektiWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@objid", _ID);
			comm.Parameters.AddWithValue("@objvrsta", 1);
			comm.Parameters.AddWithValue("@pripada", _Magacin);
			comm.Parameters.AddWithValue("@sifra", _Sifra);
			comm.Parameters.AddWithValue("@naziv", _Naziv);
			comm.Parameters.AddWithValue("@adresa", _Adresa);
			comm.Parameters.AddWithValue("@mesto", _Mesto);
			comm.Parameters.AddWithValue("@vazi", _Vazi);
			return m_DB.GetData(comm, ref _Error);
		}

		public static DataTable EvidentirajKnjige(int _ID, string _ISBN, string _Naslov, string _Autor, int _Godina, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("KnjigeWork");
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.AddWithValue("@bookid", _ID);
			comm.Parameters.AddWithValue("@isbn", _ISBN);
			comm.Parameters.AddWithValue("@naslov", _Naslov);
			comm.Parameters.AddWithValue("@autor", _Autor);
			comm.Parameters.AddWithValue("@godina", _Godina);
			//comm.Parameters.AddWithValue("@vazi", _Vazi)
			return m_DB.GetData(comm, ref _Error);
		}

		public static DataTable VratiSpisakMagacina(ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Magacini()", ref _Error);
		}

		public static DataTable VratiKnjizareZaMagacin(int _ID, ref string _Error)
		{
			if (_ID == 0)
			{
				return m_DB.GetData("SELECT * FROM Knjizare()", ref _Error);
			}
			else
			{
				return m_DB.GetData("SELECT * FROM KnjizareZa(" + _ID.ToString() + ")", ref _Error);
			}
		}

		public static DataTable VratiSveZaposlene(ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM VZaposleni", ref _Error);
		}

		private static DataTable VratiDokumente(int _DocID, int _ObjID, int _VrstaDoc, int _Vrsta, DateTime _Datum, string _Status, int _Broj, string _Oznaka, ref string _Error)
		{

			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("DokumentaWork");
			comm.CommandType = CommandType.StoredProcedure;

			comm.Parameters.AddWithValue("@objid", _ObjID);
			comm.Parameters.AddWithValue("@vrstadoc", _VrstaDoc);
			comm.Parameters.AddWithValue("@broj", _Broj);
			comm.Parameters.AddWithValue("@vrsta", _Vrsta);
			comm.Parameters.AddWithValue("@docid", _DocID);
			comm.Parameters.AddWithValue("@oznaka", _Oznaka);
			comm.Parameters.AddWithValue("@datum", Convert.ToDateTime(_Datum));
			comm.Parameters.AddWithValue("@empid", EmpID);
			comm.Parameters.AddWithValue("@status", _Status);
			return m_DB.GetData(comm, ref _Error);
		}

		public static bool EvidentirajDostavljenuKolicinu(int _DocID, int _GookID, int _Zahtevano, int _Odobreno, ref string _Error)
		{
			System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand("PrometWork");
			comm.CommandType = CommandType.StoredProcedure;

			comm.Parameters.AddWithValue("@docid", _DocID);
			comm.Parameters.AddWithValue("@bookid", _GookID);
			comm.Parameters.AddWithValue("@zahtevano", _Zahtevano);
			comm.Parameters.AddWithValue("@odobreno", _Odobreno);
			return m_DB.Execute(comm, ref _Error);
		}

		//Dodatak
		public static DataTable VratiAktivneZaposlene(ref string _Error)
		{
			return m_DB.GetData("SELECT empid,vrsta,objid,ime,sifra,vazi FROM Zaposleni where vazi = '1' and sifra <> 'admin'", ref _Error);
		}

		public static DataTable VratiSpisakVrstaRM(ref string _Error, int _Bez = 0)
		{
			if (_Bez == 0)
			{
				return m_DB.GetData("SELECT * FROM VrstaRM", ref _Error);
			}
			else
			{
				return m_DB.GetData("SELECT * FROM VrstaRM where vrsta <> " + _Bez.ToString(), ref _Error);
			}
		}

		public static DataTable VratiPrometZaObjekat(int _ID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM PrometZa(" + _ID.ToString() + ")", ref _Error);
		}

		public static DataTable VratiStanjeZaObjekat(int _ID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Stanje(" + _ID.ToString() + ")", ref _Error);
		}

		public static int VratiMagacinZaKnjizaru(int _ID, ref string _Error)
		{
			int i = 0;
			try
			{
				i = Convert.ToInt32(m_DB.GetValue("SELECT dbo.MagacinZa(" + _ID.ToString() + ")", ref _Error));
			}
			catch (Exception ex)
			{
				if (_Error != null)
				{
					_Error += "\r\n" + ex.Message;
				}
				else
				{
					_Error = ex.Message;
				}
			}
			return i;
		}

		public static DataTable VratiSpisakPrijemnica(int _ID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM ZaPrijemnicu(" + _ID.ToString() + ")", ref _Error);
		}

		public static DataTable VratiStavkeDokumenta(int _DocID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM DocStavke(" + _DocID.ToString() + ")", ref _Error);
		}

		public static DataTable VratiPodatkeODokumentu(int _DocID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Dokumenta WHERE docid = " + _DocID.ToString(), ref _Error);
		}

		public static DataTable VratiObjekatInfo(int _ObjID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Objekti WHERE objid = " + _ObjID.ToString(), ref _Error);
		}

		public static DataTable VratiViewButtons(int _OptionID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Moze(" + _OptionID.ToString() + ")", ref _Error);
		}

		public static DataTable VratiKnjigeZaProdaju(int _ObjID, ref string _Error)
		{
			string s = "select a.objid,a.bookid,a.ISBN,a.Naslov,a.Autor,k.Cena,a.Stanje from stanje(" + _ObjID.ToString() + ") a inner join knjige k on a.bookid = k.bookid where stanje > 0";
			return m_DB.GetData(s, ref _Error);
		}

		public static DataTable VratiPodatkeOPrijavljenomKorisniku(ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Zaposleni WHERE empid = " + EmpID.ToString(), ref _Error);
		}

		public static DataTable VrstaRMInfo(int _RM, ref string _Error)
		{
			return m_DB.GetData("SELECT naziv from VrstaRM where vrsta = " + _RM.ToString(), ref _Error);
		}

		public static bool UpdateStatusDokumenta(string _NewStatus, int _VrstaDoc, string _ActiveStatus, int _ObjID, ref string _Error)
		{
			string s = "update Dokumenta set status = '" + _NewStatus + "' where vrstadoc = " + _VrstaDoc.ToString() + " and status = '" + _ActiveStatus + "' and obju = " + _ObjID.ToString();
			return m_DB.Execute(s, ref _Error);
		}

		public static DataTable VratiSpisakKnjiga(ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Knjige", ref _Error);
		}

		public static DataTable VratiPodatkeOKnjizi(int _bookID, ref string _Error)
		{
			return m_DB.GetData("SELECT * FROM Knjige WHERE bookid = " + _bookID.ToString(), ref _Error);
		}

		public static bool AzurirajPodatkeOKnjizi(ref int _BookID, string _ISBN, string _Naslov, string _Autor, int _Godina, decimal _Cena, ref string _Error)
		{
			bool fja = false;
			if (Convert.ToInt32(m_DB.GetValue("SELECT COUNT(*) As Broj FROM Knjige WHERE ISBN = '" + _ISBN + "'", ref _Error)) > 0)
			{
				_BookID = Convert.ToInt32(m_DB.GetValue("SELECT BookID FROM Knjige WHERE ISBN = '" + _ISBN + "'", ref _Error));
				fja = m_DB.Execute("UPDATE Knjige SET ISBN = '" + _ISBN + "',Autor = '" + _Autor + "',Naslov = '" + _Naslov + "',Godina = " + _Godina.ToString() + ",Cena = " + Microsoft.VisualBasic.Strings.FormatNumber(_Cena, 2, Microsoft.VisualBasic.TriState.True, Microsoft.VisualBasic.TriState.UseDefault, Microsoft.VisualBasic.TriState.False).Replace(",", "."), ref _Error);
			}
			else
			{
				fja = m_DB.Execute("INSERT INTO Knjige(ISBN,NASLOV,AUTOR,GODINA,CENA) SELECT '" + _ISBN + "','" + _Naslov + "','" + _Autor + "'," + _Godina.ToString() + "," + Microsoft.VisualBasic.Strings.FormatNumber(_Cena, 2, Microsoft.VisualBasic.TriState.True, Microsoft.VisualBasic.TriState.UseDefault, Microsoft.VisualBasic.TriState.False).Replace(",", "."), ref _Error);
				if (fja)
				{
					_BookID = Convert.ToInt32(m_DB.GetValue("SELECT Max(BookID) As BookID from Knjige", ref _Error));
					fja = (_Error == null);
				}
			}
			return fja;
		}

        public DataTable GetData(string _SQL, ref string _Error)
        {
			
            return m_DB.GetData(_SQL, ref _Error);
        }

        public DataTable GetData(SqlCommand _SQL, ref string _Error)
        {
            return m_DB.GetData(_SQL, ref _Error);
        }

        public DataSet GetDS(string _SQL, ref string _Error)
        {
            return m_DB.GetDS(_SQL, ref _Error);
        }

        public DataSet GetDS(SqlCommand _SQL, ref string _Error)
        {
            return m_DB.GetDS(_SQL, ref _Error);
        }

        public bool Execute(string _SQL, ref string _Error)
        {
            return m_DB.Execute(_SQL, ref _Error);
        }

        public bool Execute(SqlCommand _SQL, ref string _Error)
        {
            return m_DB.Execute(_SQL, ref _Error);
        }

        public object GetValue(string _SQL, ref string _Error)
        {
            return m_DB.GetValue(_SQL, ref _Error);
        }

		public static DataTable DetaljiRacuna(string _UPit, ref string _Error)
		{ return m_DB.GetData(_UPit,ref  _Error);

		}
		public static object Vrednost(string _SQL, ref string _Error)
		{
			return m_DB.GetValue(_SQL, ref _Error);
		}

		public bool Connect( ref string _Error)
		{
			if (m_DB == null)
			{
				m_DB = new DB();
			}
			return m_DB.Connect ( ref _Error);
		}

		public bool Disconnect(ref string _Error)
		{
			return m_DB.Disconnect(ref _Error);
		}

		public static bool Konektujse(ref string _Error)
		{
			return m_DB.Connect(ref _Error);
		}
	}

}